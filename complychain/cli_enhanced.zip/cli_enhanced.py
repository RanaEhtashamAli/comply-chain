"""
Enhanced CLI for ComplyChain using Typer.

This module provides a modern CLI interface with new commands for
audit verification, key rotation, model training, and compliance checking.
"""

import json
import sys
from pathlib import Path
from typing import Optional
import typer
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn

from .config.logging_config import setup_logging, get_logger
from .config import get_config
from .exceptions import ComplyChainError
from .threat_scanner import GLBAScanner
from .crypto_engine import ComplyChainCrypto, QuantumSafeSigner
from .audit_system import GLBAAuditor
from .detection.ml_engine import MLEngine

# Create Typer app
app = typer.Typer(
    name="complychain",
    help="Enterprise-grade GLBA compliance toolkit with quantum-safe cryptography",
    add_completion=False
)

# Rich console for better output
console = Console()
logger = get_logger(__name__)


def setup_cli_logging(log_level: str) -> None:
    """Set up CLI logging."""
    setup_logging(level=log_level.upper())


@app.callback()
def main(
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Enable verbose output"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Perform dry run without making changes"),
    log_level: str = typer.Option("INFO", "--log-level", help="Set log level (DEBUG/INFO/WARNING/ERROR)"),
    config_file: Optional[Path] = typer.Option(None, "--config", help="Path to configuration file")
):
    """ComplyChain - GLBA Compliance Toolkit."""
    setup_cli_logging(log_level)
    
    if verbose:
        console.print("[bold blue]ComplyChain[/bold blue] - GLBA Compliance Toolkit")
        console.print(f"Log level: {log_level}")
        console.print(f"Dry run: {dry_run}")
        if config_file:
            console.print(f"Config file: {config_file}")
    
    # Load configuration
    try:
        config = get_config(config_file)
        if verbose:
            console.print(f"Configuration loaded: {config.get('compliance.mode')} mode")
    except Exception as e:
        console.print(f"[red]Configuration error: {e}[/red]")
        sys.exit(1)


@app.command()
def scan(
    file: Path = typer.Argument(..., help="Transaction file to scan"),
    quantum_safe: bool = typer.Option(False, "--quantum-safe", help="Enable quantum-safe scanning"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output file for results")
):
    """Scan a transaction for threats and compliance."""
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console
        ) as progress:
            task = progress.add_task("Scanning transaction...", total=None)
            
            # Load transaction
            with open(file, 'r') as f:
                transaction = json.load(f)
            
            # Initialize scanner
            scanner = GLBAScanner()
            
            # Perform scan
            result = scanner.scan_transaction(transaction, quantum_safe=quantum_safe)
            
            progress.update(task, completed=True)
        
        # Display results
        if output:
            with open(output, 'w') as f:
                json.dump(result, f, indent=2)
            console.print(f"[green]Results saved to {output}[/green]")
        else:
            console.print_json(data=result)
            
    except Exception as e:
        console.print(f"[red]Scan failed: {e}[/red]")
        sys.exit(1)


@app.command()
def sign(
    file: Path = typer.Argument(..., help="File to sign"),
    quantum_safe: bool = typer.Option(False, "--quantum-safe", help="Use quantum-safe signatures"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output signature file"),
    password: Optional[str] = typer.Option(None, "--password", prompt=True, hide_input=True, help="Crypto password")
):
    """Sign a file with quantum-safe cryptography."""
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console
        ) as progress:
            task = progress.add_task("Signing file...", total=None)
            
            # Load file content
            with open(file, 'rb') as f:
                data = f.read()
            
            # Initialize crypto engine
            crypto = ComplyChainCrypto(password=password)
            
            # Generate signature
            signature = crypto.sign(data, quantum_safe=quantum_safe)
            
            progress.update(task, completed=True)
        
        # Save signature
        if output:
            with open(output, 'wb') as f:
                f.write(signature)
            console.print(f"[green]Signature saved to {output}[/green]")
        else:
            console.print(f"[green]Signature generated: {len(signature)} bytes[/green]")
            
    except Exception as e:
        console.print(f"[red]Signing failed: {e}[/red]")
        sys.exit(1)


@app.command()
def verify(
    file: Path = typer.Argument(..., help="File to verify"),
    signature: Path = typer.Argument(..., help="Signature file"),
    public_key: Optional[Path] = typer.Option(None, "--public-key", help="Public key file"),
    quantum_safe: bool = typer.Option(False, "--quantum-safe", help="Use quantum-safe verification")
):
    """Verify a file signature."""
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console
        ) as progress:
            task = progress.add_task("Verifying signature...", total=None)
            
            # Load files
            with open(file, 'rb') as f:
                data = f.read()
            
            with open(signature, 'rb') as f:
                sig_data = f.read()
            
            # Initialize crypto engine
            crypto = ComplyChainCrypto()
            
            # Verify signature
            if public_key:
                with open(public_key, 'rb') as f:
                    pub_key = f.read()
                is_valid = crypto.verify(data, sig_data, pub_key, quantum_safe=quantum_safe)
            else:
                is_valid = crypto.verify(data, sig_data, quantum_safe=quantum_safe)
            
            progress.update(task, completed=True)
        
        if is_valid:
            console.print("[green]✓ Signature is valid[/green]")
        else:
            console.print("[red]✗ Signature is invalid[/red]")
            sys.exit(1)
            
    except Exception as e:
        console.print(f"[red]Verification failed: {e}[/red]")
        sys.exit(1)


@app.command()
def report(
    report_type: str = typer.Argument(..., help="Report type (daily/monthly/incident)"),
    output: Path = typer.Option(..., "--output", "-o", help="Output PDF file"),
    start_date: Optional[str] = typer.Option(None, "--start-date", help="Start date (YYYY-MM-DD)"),
    end_date: Optional[str] = typer.Option(None, "--end-date", help="End date (YYYY-MM-DD)")
):
    """Generate compliance reports."""
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console
        ) as progress:
            task = progress.add_task("Generating report...", total=None)
            
            # Initialize auditor
            auditor = GLBAAuditor()
            
            # Generate report
            auditor.generate_report(
                report_type=report_type,
                output_file=output,
                start_date=start_date,
                end_date=end_date
            )
            
            progress.update(task, completed=True)
        
        console.print(f"[green]Report generated: {output}[/green]")
        
    except Exception as e:
        console.print(f"[red]Report generation failed: {e}[/red]")
        sys.exit(1)


@app.command()
def audit(
    action: str = typer.Argument(..., help="Audit action (verify/status)"),
    audit_file: Optional[Path] = typer.Option(None, "--file", help="Audit log file")
):
    """Audit log operations."""
    try:
        if action == "verify":
            if not audit_file:
                audit_file = Path("audit_chain/audit_log.json")
            
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console
            ) as progress:
                task = progress.add_task("Verifying audit log...", total=None)
                
                # Initialize auditor
                auditor = GLBAAuditor()
                
                # Verify audit log
                is_valid = auditor.verify_audit_log(audit_file)
                
                progress.update(task, completed=True)
            
            if is_valid:
                console.print("[green]✓ Audit log integrity verified[/green]")
            else:
                console.print("[red]✗ Audit log integrity check failed[/red]")
                sys.exit(1)
        
        elif action == "status":
            auditor = GLBAAuditor()
            status = auditor.get_audit_status()
            
            # Create status table
            table = Table(title="Audit Log Status")
            table.add_column("Metric", style="cyan")
            table.add_column("Value", style="magenta")
            
            for key, value in status.items():
                table.add_row(key, str(value))
            
            console.print(table)
        
        else:
            console.print(f"[red]Unknown audit action: {action}[/red]")
            sys.exit(1)
            
    except Exception as e:
        console.print(f"[red]Audit operation failed: {e}[/red]")
        sys.exit(1)


@app.command()
def key(
    action: str = typer.Argument(..., help="Key action (rotate/info)"),
    password: Optional[str] = typer.Option(None, "--password", prompt=True, hide_input=True, help="Crypto password")
):
    """Key management operations."""
    try:
        if action == "rotate":
            new_password = typer.prompt("New password", hide_input=True)
            
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console
            ) as progress:
                task = progress.add_task("Rotating keys...", total=None)
                
                # Initialize crypto engine
                crypto = ComplyChainCrypto(password=password)
                
                # Rotate keys
                crypto.rotate_keys(new_password)
                
                progress.update(task, completed=True)
            
            console.print("[green]✓ Keys rotated successfully[/green]")
        
        elif action == "info":
            crypto = ComplyChainCrypto()
            info = crypto.get_key_info()
            
            # Create info table
            table = Table(title="Key Information")
            table.add_column("Property", style="cyan")
            table.add_column("Value", style="magenta")
            
            for key, value in info.items():
                table.add_row(key, str(value))
            
            console.print(table)
        
        else:
            console.print(f"[red]Unknown key action: {action}[/red]")
            sys.exit(1)
            
    except Exception as e:
        console.print(f"[red]Key operation failed: {e}[/red]")
        sys.exit(1)


@app.command()
def train_model(
    input_file: Path = typer.Argument(..., help="Training data file"),
    validation_file: Optional[Path] = typer.Option(None, "--validation", help="Validation data file"),
    model_path: Optional[Path] = typer.Option(None, "--model-path", help="Model output path")
):
    """Train ML model for threat detection."""
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console
        ) as progress:
            task = progress.add_task("Training ML model...", total=None)
            
            # Load training data
            with open(input_file, 'r') as f:
                training_data = json.load(f)
            
            validation_data = None
            if validation_file:
                with open(validation_file, 'r') as f:
                    validation_data = json.load(f)
            
            # Initialize ML engine
            ml_engine = MLEngine(model_path=model_path)
            
            # Train model
            metrics = ml_engine.train(training_data, validation_data)
            
            progress.update(task, completed=True)
        
        # Display metrics
        table = Table(title="Training Metrics")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="magenta")
        
        for key, value in metrics.items():
            table.add_row(key, f"{value:.4f}" if isinstance(value, float) else str(value))
        
        console.print(table)
        console.print("[green]✓ Model training completed[/green]")
        
    except Exception as e:
        console.print(f"[red]Model training failed: {e}[/red]")
        sys.exit(1)


@app.command()
def compliance(
    action: str = typer.Argument(..., help="Compliance action (show/check)"),
    config_file: Optional[Path] = typer.Option(None, "--config", help="Configuration file")
):
    """Compliance operations."""
    try:
        if action == "show":
            config = get_config(config_file)
            
            # Create compliance table
            table = Table(title="GLBA Compliance Status")
            table.add_column("Section", style="cyan")
            table.add_column("Status", style="magenta")
            table.add_column("Implementation", style="green")
            
            glba_sections = [
                ("§314.4(c)(1)", "Data Encryption", "threat_scanner"),
                ("§314.4(c)(2)", "Access Controls", "crypto_engine"),
                ("§314.4(c)(3)", "Device Authentication", "audit_system"),
                ("§314.4(b)", "Audit Trails", "audit_system"),
                ("§314.4(d)", "Incident Response", "audit_system"),
                ("§314.4(f)", "Employee Training", "threat_scanner"),
            ]
            
            for section, description, module in glba_sections:
                status = "✓" if config.get(f"compliance.{section}", False) else "⚠"
                table.add_row(section, status, module)
            
            console.print(table)
        
        elif action == "check":
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console
            ) as progress:
                task = progress.add_task("Checking compliance...", total=None)
                
                # Perform compliance check
                scanner = GLBAScanner()
                auditor = GLBAAuditor()
                crypto = ComplyChainCrypto()
                
                # Check each component
                checks = {
                    "Threat Scanner": scanner.is_operational(),
                    "Audit System": auditor.is_operational(),
                    "Crypto Engine": crypto.is_operational(),
                }
                
                progress.update(task, completed=True)
            
            # Display results
            table = Table(title="Compliance Check Results")
            table.add_column("Component", style="cyan")
            table.add_column("Status", style="magenta")
            
            for component, status in checks.items():
                status_icon = "✓" if status else "✗"
                table.add_row(component, status_icon)
            
            console.print(table)
        
        else:
            console.print(f"[red]Unknown compliance action: {action}[/red]")
            sys.exit(1)
            
    except Exception as e:
        console.print(f"[red]Compliance operation failed: {e}[/red]")
        sys.exit(1)


@app.command()
def benchmark(
    samples: int = typer.Option(1000, "--samples", "-s", help="Number of samples to test"),
    quantum_safe: bool = typer.Option(False, "--quantum-safe", help="Test quantum-safe operations")
):
    """Run performance benchmarks."""
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console
        ) as progress:
            task = progress.add_task("Running benchmarks...", total=None)
            
            # Initialize components
            scanner = GLBAScanner()
            crypto = ComplyChainCrypto()
            auditor = GLBAAuditor()
            
            # Run benchmarks
            results = {
                "Scan Performance": scanner.benchmark(samples),
                "Crypto Performance": crypto.benchmark(samples, quantum_safe),
                "Audit Performance": auditor.benchmark(samples),
            }
            
            progress.update(task, completed=True)
        
        # Display results
        table = Table(title="Performance Benchmark Results")
        table.add_column("Operation", style="cyan")
        table.add_column("Avg Time (ms)", style="magenta")
        table.add_column("Throughput (ops/s)", style="green")
        
        for operation, metrics in results.items():
            avg_time = metrics.get("avg_time_ms", 0)
            throughput = metrics.get("throughput_ops_per_sec", 0)
            table.add_row(operation, f"{avg_time:.2f}", f"{throughput:.0f}")
        
        console.print(table)
        
    except Exception as e:
        console.print(f"[red]Benchmark failed: {e}[/red]")
        sys.exit(1)


@app.command()
def quantum_sign(
    file: Path = typer.Argument(..., help="File to sign with quantum-safe cryptography"),
    algorithm: str = typer.Option("Dilithium3", "--algorithm", "-a", help="Quantum-safe algorithm (Dilithium3/RSA-4096)"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output signature file"),
    key_file: Optional[Path] = typer.Option(None, "--key-file", help="Private key file (PEM format)")
):
    """Sign a file with quantum-safe cryptography."""
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console
        ) as progress:
            task = progress.add_task("Signing with quantum-safe cryptography...", total=None)
            
            # Load file content
            with open(file, 'rb') as f:
                data = f.read()
            
            # Initialize quantum-safe signer
            signer = QuantumSafeSigner(algorithm=algorithm)
            
            # Load existing keys or generate new ones
            if key_file and key_file.exists():
                with open(key_file, 'r') as f:
                    private_pem = f.read()
                signer.import_private_key_pem(private_pem)
                console.print(f"[yellow]Loaded existing {algorithm} private key[/yellow]")
            else:
                private_key, public_key = signer.generate_keys()
                console.print(f"[green]Generated new {algorithm} key pair[/green]")
            
            # Generate signature
            signature = signer.sign(data)
            
            progress.update(task, completed=True)
        
        # Save signature
        if output:
            with open(output, 'wb') as f:
                f.write(signature)
            console.print(f"[green]Signature saved to {output}[/green]")
        else:
            console.print(f"[green]Signature generated: {len(signature)} bytes[/green]")
            
    except Exception as e:
        console.print(f"[red]Quantum signing failed: {e}[/red]")
        sys.exit(1)


@app.command()
def quantum_verify(
    file: Path = typer.Argument(..., help="File to verify"),
    signature: Path = typer.Argument(..., help="Signature file"),
    public_key: Path = typer.Argument(..., help="Public key file (PEM format)"),
    algorithm: str = typer.Option("Dilithium3", "--algorithm", "-a", help="Quantum-safe algorithm (Dilithium3/RSA-4096)")
):
    """Verify a file signature using quantum-safe cryptography."""
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console
        ) as progress:
            task = progress.add_task("Verifying with quantum-safe cryptography...", total=None)
            
            # Load files
            with open(file, 'rb') as f:
                data = f.read()
            
            with open(signature, 'rb') as f:
                sig_data = f.read()
            
            with open(public_key, 'r') as f:
                pub_key_pem = f.read()
            
            # Initialize quantum-safe signer
            signer = QuantumSafeSigner(algorithm=algorithm)
            signer.import_public_key_pem(pub_key_pem)
            
            # Verify signature
            is_valid = signer.verify(data, sig_data, signer._public_key)
            
            progress.update(task, completed=True)
        
        if is_valid:
            console.print(f"[green]✓ {algorithm} signature is valid[/green]")
        else:
            console.print(f"[red]✗ {algorithm} signature is invalid[/red]")
            sys.exit(1)
            
    except Exception as e:
        console.print(f"[red]Quantum verification failed: {e}[/red]")
        sys.exit(1)


@app.command()
def quantum_keys(
    action: str = typer.Argument(..., help="Key action (generate/export/import)"),
    algorithm: str = typer.Option("Dilithium3", "--algorithm", "-a", help="Quantum-safe algorithm (Dilithium3/RSA-4096)"),
    output_dir: Optional[Path] = typer.Option(None, "--output-dir", "-o", help="Output directory for keys"),
    private_key_file: Optional[Path] = typer.Option(None, "--private-key", help="Private key file for import/export"),
    public_key_file: Optional[Path] = typer.Option(None, "--public-key", help="Public key file for import/export")
):
    """Manage quantum-safe cryptographic keys."""
    try:
        signer = QuantumSafeSigner(algorithm=algorithm)
        
        if action == "generate":
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console
            ) as progress:
                task = progress.add_task(f"Generating {algorithm} keys...", total=None)
                
                private_key, public_key = signer.generate_keys()
                
                progress.update(task, completed=True)
            
            # Export keys to files
            if output_dir:
                output_dir.mkdir(parents=True, exist_ok=True)
                private_pem = signer.export_private_key_pem()
                public_pem = signer.export_public_key_pem()
                
                private_path = output_dir / f"{algorithm.lower()}_private.pem"
                public_path = output_dir / f"{algorithm.lower()}_public.pem"
                
                with open(private_path, 'w') as f:
                    f.write(private_pem)
                with open(public_path, 'w') as f:
                    f.write(public_pem)
                
                console.print(f"[green]Generated {algorithm} keys:[/green]")
                console.print(f"  Private: {private_path}")
                console.print(f"  Public: {public_path}")
            else:
                console.print(f"[green]Generated {algorithm} key pair[/green]")
        
        elif action == "export":
            if not private_key_file or not public_key_file:
                console.print("[red]Both --private-key and --public-key are required for export[/red]")
                sys.exit(1)
            
            private_pem = signer.export_private_key_pem()
            public_pem = signer.export_public_key_pem()
            
            with open(private_key_file, 'w') as f:
                f.write(private_pem)
            with open(public_key_file, 'w') as f:
                f.write(public_pem)
            
            console.print(f"[green]Exported {algorithm} keys:[/green]")
            console.print(f"  Private: {private_key_file}")
            console.print(f"  Public: {public_key_file}")
        
        elif action == "import":
            if not private_key_file or not public_key_file:
                console.print("[red]Both --private-key and --public-key are required for import[/red]")
                sys.exit(1)
            
            with open(private_key_file, 'r') as f:
                private_pem = f.read()
            with open(public_key_file, 'r') as f:
                public_pem = f.read()
            
            signer.import_private_key_pem(private_pem)
            signer.import_public_key_pem(public_pem)
            
            console.print(f"[green]Imported {algorithm} keys successfully[/green]")
        
        else:
            console.print(f"[red]Unknown action: {action}[/red]")
            sys.exit(1)
            
    except Exception as e:
        console.print(f"[red]Quantum key management failed: {e}[/red]")
        sys.exit(1)


if __name__ == "__main__":
    app() 