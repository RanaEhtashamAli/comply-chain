#!/usr/bin/env python3
"""
Hybrid Crypto Engine for ComplyChain
Supports both traditional RSA and quantum-resistant Dilithium
"""

import os
import json
import logging
import tempfile
import hashlib
import ctypes
from typing import Optional, Tuple, Dict, Any
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from datetime import datetime

try:
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa, padding
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    from cryptography.hazmat.backends import default_backend
    CRYPTOGRAPHY_AVAILABLE = True
except ImportError:
    CRYPTOGRAPHY_AVAILABLE = False

try:
    from pqcrypto import dilithium3
    DILITHIUM_AVAILABLE = True
except ImportError:
    DILITHIUM_AVAILABLE = False

# Performance-optimized parameters for production use
SCRYPT_N = 2**14  # 16384 iterations (production-optimized)
SCRYPT_R = 8     # Memory cost
SCRYPT_P = 1     # Parallelization
MIN_SALT_LEN = 32  # 256-bit salt

class CryptoAlgorithm(Enum):
    """Supported cryptographic algorithms"""
    RSA_4096 = "RSA-4096"
    DILITHIUM3 = "DILITHIUM3"

@dataclass
class CryptoConfig:
    """Cryptographic configuration"""
    algorithm: CryptoAlgorithm
    key_size: int
    scrypt_n: int
    scrypt_r: int
    scrypt_p: int
    salt_length: int
    version: str

class KeyManager:
    """Manages cryptographic key lifecycle"""
    
    def __init__(self, algorithm: CryptoAlgorithm = CryptoAlgorithm.RSA_4096):
        self.algorithm = algorithm
        self.logger = logging.getLogger(__name__)
        self._private_key = None
        self._public_key = None
        self._locked_buffers = []
        
        # Algorithm-specific configurations
        self.config = self._get_algorithm_config(algorithm)
    
    def _get_algorithm_config(self, algorithm: CryptoAlgorithm) -> CryptoConfig:
        """Get configuration for specified algorithm"""
        if algorithm == CryptoAlgorithm.RSA_4096:
            return CryptoConfig(
                algorithm=algorithm,
                key_size=4096,
                scrypt_n=SCRYPT_N,
                scrypt_r=SCRYPT_R,
                scrypt_p=SCRYPT_P,
                salt_length=MIN_SALT_LEN,
                version="2.0"
            )
        elif algorithm == CryptoAlgorithm.DILITHIUM3:
            return CryptoConfig(
                algorithm=algorithm,
                key_size=1952,  # Dilithium3 public key size
                scrypt_n=SCRYPT_N,
                scrypt_r=SCRYPT_R,
                scrypt_p=SCRYPT_P,
                salt_length=MIN_SALT_LEN,
                version="3.0"
            )
        else:
            raise ValueError(f"Unsupported algorithm: {algorithm}")
    
    def generate_keys(self, password: str) -> Tuple[bytes, bytes]:
        """Generate new key pair"""
        self.logger.info(f"Generating {self.algorithm.value} key pair")
        
        if self.algorithm == CryptoAlgorithm.RSA_4096:
            return self._generate_rsa_keys(password)
        elif self.algorithm == CryptoAlgorithm.DILITHIUM3:
            return self._generate_dilithium_keys(password)
        else:
            raise ValueError(f"Unsupported algorithm: {self.algorithm}")
    
    def _generate_rsa_keys(self, password: str) -> Tuple[bytes, bytes]:
        """Generate RSA-4096 key pair"""
        if not CRYPTOGRAPHY_AVAILABLE:
            raise RuntimeError("cryptography library not available")
        
        # Generate RSA private key
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=4096,
            backend=default_backend()
        )
        
        # Serialize keys
        private_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.BestAvailableEncryption(
                password.encode()
            )
        )
        
        public_key = private_key.public_key()
        public_pem = public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        
        return private_pem, public_pem
    
    def _generate_dilithium_keys(self, password: str) -> Tuple[bytes, bytes]:
        """Generate Dilithium3 key pair"""
        if not DILITHIUM_AVAILABLE:
            raise RuntimeError("pqcrypto library not available")
        
        # Generate Dilithium3 key pair
        public_key, private_key = dilithium3.keypair()
        
        # Encrypt private key with password
        salt = os.urandom(self.config.salt_length)
        key = self._derive_key(password, salt)
        
        # Use AES-GCM for private key encryption
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        aesgcm = AESGCM(key)
        nonce = os.urandom(12)
        
        encrypted_private = aesgcm.encrypt(nonce, private_key, b"")
        
        # Store encrypted private key with metadata
        private_data = {
            'algorithm': self.algorithm.value,
            'version': self.config.version,
            'salt': salt.hex(),
            'nonce': nonce.hex(),
            'encrypted_key': encrypted_private.hex(),
            'scrypt_params': {
                'n': self.config.scrypt_n,
                'r': self.config.scrypt_r,
                'p': self.config.scrypt_p
            }
        }
        
        return json.dumps(private_data).encode(), public_key
    
    def _derive_key(self, password: str, salt: bytes) -> bytes:
        """Derive encryption key using scrypt"""
        import scrypt
        
        key = scrypt.hash(
            password.encode(),
            salt,
            N=self.config.scrypt_n,
            r=self.config.scrypt_r,
            p=self.config.scrypt_p,
            buflen=32
        )
        
        # Lock key in memory
        key_array = bytearray(key)
        self._locked_buffers.append(key_array)
        
        return bytes(key_array)
    
    def _clear_sensitive_data(self):
        """Clear sensitive data from memory"""
        for buffer in self._locked_buffers:
            self._zeroize(buffer)
        self._locked_buffers.clear()
    
    def _zeroize(self, data: bytearray):
        """Securely zeroize memory"""
        try:
            # Try to use libsodium if available
            import nacl.utils
            nacl.utils.sodium_memzero(data)
        except ImportError:
            # Fallback to ctypes
            ctypes.memset(ctypes.addressof(data), 0, len(data))

class HybridCryptoEngine:
    """
    Hybrid Cryptographic Engine
    Supports both traditional RSA and quantum-resistant Dilithium
    """
    
    def __init__(self, algorithm: CryptoAlgorithm = CryptoAlgorithm.RSA_4096):
        self.algorithm = algorithm
        self.logger = logging.getLogger(__name__)
        self.key_manager = KeyManager(algorithm)
        self._private_key = None
        self._public_key = None
        
        # Validate algorithm availability
        self._validate_algorithm_availability()
    
    def _validate_algorithm_availability(self):
        """Validate that required libraries are available"""
        if self.algorithm == CryptoAlgorithm.RSA_4096 and not CRYPTOGRAPHY_AVAILABLE:
            raise RuntimeError("cryptography library required for RSA-4096")
        elif self.algorithm == CryptoAlgorithm.DILITHIUM3 and not DILITHIUM_AVAILABLE:
            raise RuntimeError("pqcrypto library required for Dilithium3")
    
    def initialize(self, password: str, key_store_path: Optional[str] = None):
        """Initialize crypto engine with password"""
        self.logger.info(f"Initializing {self.algorithm.value} crypto engine")
        
        if key_store_path and os.path.exists(key_store_path):
            # Load existing keys
            self._load_keys(password, key_store_path)
        else:
            # Generate new keys
            private_key, public_key = self.key_manager.generate_keys(password)
            self._private_key = private_key
            self._public_key = public_key
            
            # Save keys if path provided
            if key_store_path:
                self._save_keys(key_store_path)
    
    def _load_keys(self, password: str, key_store_path: str):
        """Load existing keys from storage"""
        try:
            with open(key_store_path, 'r') as f:
                key_data = json.load(f)
            
            if self.algorithm == CryptoAlgorithm.RSA_4096:
                self._load_rsa_keys(password, key_data)
            elif self.algorithm == CryptoAlgorithm.DILITHIUM3:
                self._load_dilithium_keys(password, key_data)
                
        except Exception as e:
            self.logger.error(f"Failed to load keys: {e}")
            raise
    
    def _load_rsa_keys(self, password: str, key_data: Dict):
        """Load RSA keys"""
        if not CRYPTOGRAPHY_AVAILABLE:
            raise RuntimeError("cryptography library not available")
        
        # Load private key
        private_pem = key_data['private_key'].encode()
        self._private_key = serialization.load_pem_private_key(
            private_pem,
            password=password.encode(),
            backend=default_backend()
        )
        
        # Extract public key
        self._public_key = self._private_key.public_key()
    
    def _load_dilithium_keys(self, password: str, key_data: Dict):
        """Load Dilithium keys"""
        if not DILITHIUM_AVAILABLE:
            raise RuntimeError("pqcrypto library not available")
        
        # Decrypt private key
        salt = bytes.fromhex(key_data['salt'])
        nonce = bytes.fromhex(key_data['nonce'])
        encrypted_key = bytes.fromhex(key_data['encrypted_key'])
        
        key = self.key_manager._derive_key(password, salt)
        
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        aesgcm = AESGCM(key)
        
        private_key = aesgcm.decrypt(nonce, encrypted_key, b"")
        self._private_key = private_key
        self._public_key = key_data['public_key']
    
    def _save_keys(self, key_store_path: str):
        """Save keys to storage"""
        key_data = {
            'algorithm': self.algorithm.value,
            'version': self.key_manager.config.version,
            'created': str(datetime.now()),
            'scrypt_params': {
                'n': self.key_manager.config.scrypt_n,
                'r': self.key_manager.config.scrypt_r,
                'p': self.key_manager.config.scrypt_p
            }
        }
        
        if self.algorithm == CryptoAlgorithm.RSA_4096:
            key_data['private_key'] = self._private_key.decode()
            key_data['public_key'] = self._public_key.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
            ).decode()
        elif self.algorithm == CryptoAlgorithm.DILITHIUM3:
            key_data['private_key'] = self._private_key.hex()
            key_data['public_key'] = self._public_key.hex()
        
        # Save with secure permissions
        with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
            json.dump(key_data, f, indent=2)
            temp_path = f.name
        
        # Atomic move with secure permissions
        os.chmod(temp_path, 0o600)
        os.rename(temp_path, key_store_path)
    
    def sign(self, data: bytes) -> Tuple[bytes, bytes]:
        """Sign data and return signature with public key"""
        if not self._private_key:
            raise RuntimeError("Crypto engine not initialized")
        
        if self.algorithm == CryptoAlgorithm.RSA_4096:
            return self._sign_rsa(data)
        elif self.algorithm == CryptoAlgorithm.DILITHIUM3:
            return self._sign_dilithium(data)
        else:
            raise ValueError(f"Unsupported algorithm: {self.algorithm}")
    
    def _sign_rsa(self, data: bytes) -> Tuple[bytes, bytes]:
        """Sign data with RSA-4096"""
        signature = self._private_key.sign(
            data,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )
        
        public_key_bytes = self._public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        
        return signature, public_key_bytes
    
    def _sign_dilithium(self, data: bytes) -> Tuple[bytes, bytes]:
        """Sign data with Dilithium3"""
        signature = dilithium3.sign(self._private_key, data)
        return signature, self._public_key
    
    def verify(self, data: bytes, signature: bytes, public_key: bytes) -> bool:
        """Verify signature"""
        try:
            if self.algorithm == CryptoAlgorithm.RSA_4096:
                return self._verify_rsa(data, signature, public_key)
            elif self.algorithm == CryptoAlgorithm.DILITHIUM3:
                return self._verify_dilithium(data, signature, public_key)
            else:
                raise ValueError(f"Unsupported algorithm: {self.algorithm}")
        except Exception as e:
            self.logger.warning(f"Signature verification failed: {e}")
            return False
    
    def _verify_rsa(self, data: bytes, signature: bytes, public_key: bytes) -> bool:
        """Verify RSA signature"""
        try:
            pub_key = serialization.load_pem_public_key(public_key, backend=default_backend())
            pub_key.verify(
                signature,
                data,
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH
                ),
                hashes.SHA256()
            )
            return True
        except Exception:
            return False
    
    def _verify_dilithium(self, data: bytes, signature: bytes, public_key: bytes) -> bool:
        """Verify Dilithium signature"""
        try:
            dilithium3.verify(public_key, data, signature)
            return True
        except Exception:
            return False
    
    def get_public_key(self) -> bytes:
        """Get public key"""
        if not self._public_key:
            raise RuntimeError("Crypto engine not initialized")
        
        if self.algorithm == CryptoAlgorithm.RSA_4096:
            return self._public_key.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
            )
        else:
            return self._public_key
    
    def get_algorithm_info(self) -> Dict[str, Any]:
        """Get algorithm information"""
        return {
            'algorithm': self.algorithm.value,
            'key_size': self.key_manager.config.key_size,
            'scrypt_n': self.key_manager.config.scrypt_n,
            'scrypt_r': self.key_manager.config.scrypt_r,
            'scrypt_p': self.key_manager.config.scrypt_p,
            'version': self.key_manager.config.version,
            'quantum_resistant': self.algorithm == CryptoAlgorithm.DILITHIUM3
        }
    
    def cleanup(self):
        """Clean up sensitive data"""
        self.key_manager._clear_sensitive_data()
        self._private_key = None
        self._public_key = None

# Utility functions
def get_supported_algorithms() -> Dict[str, bool]:
    """Get list of supported algorithms and their availability"""
    return {
        'RSA-4096': CRYPTOGRAPHY_AVAILABLE,
        'DILITHIUM3': DILITHIUM_AVAILABLE
    }

def validate_algorithm_choice(algorithm: str) -> bool:
    """Validate algorithm choice"""
    supported = get_supported_algorithms()
    return algorithm in supported and supported[algorithm]

def get_algorithm_recommendation() -> str:
    """Get recommended algorithm based on availability"""
    if DILITHIUM_AVAILABLE:
        return "DILITHIUM3"  # Quantum-resistant
    elif CRYPTOGRAPHY_AVAILABLE:
        return "RSA-4096"    # Traditional
    else:
        raise RuntimeError("No supported cryptographic libraries available") 