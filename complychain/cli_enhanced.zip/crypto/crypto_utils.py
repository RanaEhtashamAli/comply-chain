"""
Cryptographic utilities for ComplyChain.

This module provides helper functions for cryptographic operations,
memory management, and key validation.
"""

import os
import ctypes
import hashlib
from pathlib import Path
from typing import Optional, Tuple, List
import platform

from ..exceptions import (
    KeyValidationError, 
    MemoryProtectionError, 
    FilePermissionError,
    SignatureVerificationError
)
from ..config.logging_config import get_logger

logger = get_logger(__name__)


class MemoryManager:
    """Secure memory management utilities."""
    
    def __init__(self):
        self._locked_buffers: List[bytearray] = []
        self._is_windows = platform.system() == "Windows"
    
    def secure_zeroize(self, buffer: bytearray) -> None:
        """
        Securely zeroize a buffer using ctypes.memset.
        
        Args:
            buffer: Buffer to zeroize
        """
        try:
            ctypes.memset(ctypes.c_char_p(bytes(buffer)), 0, len(buffer))
        except Exception as e:
            logger.error(f"Failed to zeroize buffer: {e}")
            # Fallback to Python zeroing
            for i in range(len(buffer)):
                buffer[i] = 0
    
    def lock_memory(self, buffer: bytearray) -> bool:
        """
        Lock memory to prevent swapping.
        
        Args:
            buffer: Buffer to lock
            
        Returns:
            True if successful, False otherwise
        """
        try:
            if self._is_windows:
                # Windows memory locking (requires elevated privileges)
                return self._lock_memory_windows(buffer)
            else:
                # Unix memory locking
                return self._lock_memory_unix(buffer)
        except Exception as e:
            logger.warning(f"Memory locking failed: {e}")
            return False
    
    def _lock_memory_windows(self, buffer: bytearray) -> bool:
        """Lock memory on Windows."""
        try:
            # Windows-specific memory locking would go here
            # For now, just track the buffer
            self._locked_buffers.append(buffer)
            return True
        except Exception:
            return False
    
    def _lock_memory_unix(self, buffer: bytearray) -> bool:
        """Lock memory on Unix systems."""
        try:
            # Unix memory locking would go here
            # For now, just track the buffer
            self._locked_buffers.append(buffer)
            return True
        except Exception:
            return False
    
    def unlock_memory(self, buffer: bytearray) -> None:
        """
        Unlock memory and zeroize.
        
        Args:
            buffer: Buffer to unlock
        """
        if buffer in self._locked_buffers:
            self._locked_buffers.remove(buffer)
            self.secure_zeroize(buffer)
    
    def cleanup(self) -> None:
        """Clean up all locked buffers."""
        for buffer in self._locked_buffers[:]:
            self.unlock_memory(buffer)


class KeyValidator:
    """Key validation utilities."""
    
    @staticmethod
    def validate_key_structure(key_data: bytes, expected_length: int) -> bool:
        """
        Validate key structure and length.
        
        Args:
            key_data: Key data to validate
            expected_length: Expected key length
            
        Returns:
            True if valid, False otherwise
        """
        if len(key_data) != expected_length:
            return False
        
        # Check for all-zero or all-one patterns (weak keys)
        if all(b == 0 for b in key_data) or all(b == 255 for b in key_data):
            return False
        
        return True
    
    @staticmethod
    def validate_public_key(public_key: bytes) -> bool:
        """
        Validate public key format.
        
        Args:
            public_key: Public key to validate
            
        Returns:
            True if valid, False otherwise
        """
        # Dilithium3 public key length check
        if len(public_key) != 1952:  # Dilithium3 public key size
            return False
        
        return True
    
    @staticmethod
    def check_weak_key_patterns(key_data: bytes) -> bool:
        """
        Check for weak key patterns.
        
        Args:
            key_data: Key data to check
            
        Returns:
            True if weak patterns detected, False otherwise
        """
        # Check for repeated patterns
        if len(key_data) >= 4:
            for i in range(len(key_data) - 3):
                pattern = key_data[i:i+4]
                if key_data.count(pattern) > len(key_data) // 8:
                    return True
        
        # Check for sequential patterns
        sequential_count = 0
        for i in range(len(key_data) - 1):
            if key_data[i+1] == key_data[i] + 1:
                sequential_count += 1
                if sequential_count > len(key_data) // 4:
                    return True
            else:
                sequential_count = 0
        
        return False


class FileSecurity:
    """File security utilities."""
    
    @staticmethod
    def check_file_permissions(file_path: Path) -> None:
        """
        Check file permissions for security.
        
        Args:
            file_path: Path to check
            
        Raises:
            FilePermissionError: If permissions are insecure
        """
        if not file_path.exists():
            return
        
        try:
            stat = file_path.stat()
            
            # Check if file is readable by others
            if stat.st_mode & 0o077:
                raise FilePermissionError(
                    f"File {file_path} has insecure permissions: {oct(stat.st_mode)}"
                )
        except Exception as e:
            raise FilePermissionError(f"Failed to check file permissions: {e}")
    
    @staticmethod
    def secure_file_operations(file_path: Path) -> None:
        """
        Ensure secure file operations.
        
        Args:
            file_path: Path to secure
        """
        try:
            # Set restrictive permissions
            file_path.chmod(0o600)
        except Exception as e:
            logger.warning(f"Failed to set secure permissions: {e}")


class HashUtils:
    """Hash utility functions."""
    
    @staticmethod
    def sha3_512(data: bytes) -> bytes:
        """
        Compute SHA3-512 hash.
        
        Args:
            data: Data to hash
            
        Returns:
            Hash digest
        """
        return hashlib.sha3_512(data).digest()
    
    @staticmethod
    def compute_merkle_root(hashes: List[bytes]) -> bytes:
        """
        Compute Merkle root from list of hashes.
        
        Args:
            hashes: List of hashes
            
        Returns:
            Merkle root hash
        """
        if not hashes:
            return b''
        
        if len(hashes) == 1:
            return hashes[0]
        
        # Build Merkle tree
        current_level = hashes
        while len(current_level) > 1:
            next_level = []
            for i in range(0, len(current_level), 2):
                if i + 1 < len(current_level):
                    combined = current_level[i] + current_level[i + 1]
                else:
                    combined = current_level[i] + current_level[i]
                next_level.append(HashUtils.sha3_512(combined))
            current_level = next_level
        
        return current_level[0]


# Global memory manager instance
_memory_manager = MemoryManager()


def get_memory_manager() -> MemoryManager:
    """Get global memory manager instance."""
    return _memory_manager


def cleanup_memory() -> None:
    """Clean up all secure memory."""
    _memory_manager.cleanup() 