"""
Key management for ComplyChain cryptographic operations.

This module provides secure key storage, loading, and validation
with encrypted file operations and memory protection.
"""

import json
import os
import tempfile
from pathlib import Path
from typing import Optional, Tuple, Dict, Any
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend

from ..exceptions import (
    KeyValidationError, 
    FilePermissionError, 
    CryptoEngineError
)
from ..config.logging_config import get_logger
from .crypto_utils import KeyValidator, FileSecurity, get_memory_manager

logger = get_logger(__name__)


class KeyManager:
    """Secure key management with encrypted storage."""
    
    def __init__(self, key_store_path: Path, password: Optional[str] = None):
        """
        Initialize key manager.
        
        Args:
            key_store_path: Path to key storage directory
            password: Optional password for key encryption
        """
        self.key_store_path = Path(key_store_path)
        self.key_store_path.mkdir(parents=True, exist_ok=True)
        self.password = password
        self.memory_manager = get_memory_manager()
        
        # OWASP 2024 parameters
        self.SCRYPT_N = 16384
        self.SCRYPT_R = 8
        self.SCRYPT_P = 1
        self.MIN_SALT_LEN = 32
        
        # Key file paths
        self.private_key_file = self.key_store_path / "private_key.enc"
        self.public_key_file = self.key_store_path / "public_key.bin"
        self.key_metadata_file = self.key_store_path / "key_metadata.json"
    
    def _derive_key(self, password: str, salt: bytes) -> bytes:
        """
        Derive encryption key from password using Scrypt.
        
        Args:
            password: Password for key derivation
            salt: Salt for key derivation
            
        Returns:
            Derived key
        """
        kdf = Scrypt(
            salt=salt,
            length=32,
            n=self.SCRYPT_N,
            r=self.SCRYPT_R,
            p=self.SCRYPT_P,
            backend=default_backend()
        )
        return kdf.derive(password.encode())
    
    def _encrypt_data(self, data: bytes, password: str) -> Tuple[bytes, bytes]:
        """
        Encrypt data with AES-GCM.
        
        Args:
            data: Data to encrypt
            password: Password for encryption
            
        Returns:
            Tuple of (encrypted_data, salt)
        """
        # Generate salt
        salt = os.urandom(self.MIN_SALT_LEN)
        
        # Derive key
        key = self._derive_key(password, salt)
        
        # Generate IV
        iv = os.urandom(12)
        
        # Encrypt
        cipher = Cipher(
            algorithms.AES(key),
            modes.GCM(iv),
            backend=default_backend()
        )
        encryptor = cipher.encryptor()
        
        ciphertext = encryptor.update(data) + encryptor.finalize()
        
        # Combine IV, ciphertext, and tag
        encrypted_data = iv + encryptor.tag + ciphertext
        
        return encrypted_data, salt
    
    def _decrypt_data(self, encrypted_data: bytes, password: str, salt: bytes) -> bytes:
        """
        Decrypt data with AES-GCM.
        
        Args:
            encrypted_data: Data to decrypt
            password: Password for decryption
            salt: Salt for key derivation
            
        Returns:
            Decrypted data
        """
        # Derive key
        key = self._derive_key(password, salt)
        
        # Extract IV, tag, and ciphertext
        iv = encrypted_data[:12]
        tag = encrypted_data[12:28]
        ciphertext = encrypted_data[28:]
        
        # Decrypt
        cipher = Cipher(
            algorithms.AES(key),
            modes.GCM(iv, tag),
            backend=default_backend()
        )
        decryptor = cipher.decryptor()
        
        plaintext = decryptor.update(ciphertext) + decryptor.finalize()
        return plaintext
    
    def save_keys(self, private_key: bytes, public_key: bytes, 
                  password: Optional[str] = None) -> None:
        """
        Save keys with encryption.
        
        Args:
            private_key: Private key to save
            public_key: Public key to save
            password: Password for encryption (uses instance password if None)
        """
        if password is None:
            password = self.password
        
        if not password:
            raise CryptoEngineError("Password required for key encryption")
        
        try:
            # Validate keys
            if not KeyValidator.validate_key_structure(private_key, 4000):  # Dilithium3
                raise KeyValidationError("Invalid private key structure")
            
            if not KeyValidator.validate_public_key(public_key):
                raise KeyValidationError("Invalid public key structure")
            
            # Check for weak keys
            if KeyValidator.check_weak_key_patterns(private_key):
                raise KeyValidationError("Weak key patterns detected")
            
            # Encrypt private key
            encrypted_private, salt = self._encrypt_data(private_key, password)
            
            # Save with atomic operations
            self._atomic_save(self.private_key_file, encrypted_private)
            self._atomic_save(self.public_key_file, public_key)
            
            # Save metadata
            metadata = {
                'algorithm': 'Dilithium3',
                'key_size': len(private_key),
                'public_key_size': len(public_key),
                'salt': salt.hex(),
                'encryption': 'AES-GCM-256',
                'kdf': 'Scrypt',
                'scrypt_n': self.SCRYPT_N,
                'scrypt_r': self.SCRYPT_R,
                'scrypt_p': self.SCRYPT_P,
            }
            
            self._atomic_save_json(self.key_metadata_file, metadata)
            
            # Set secure permissions
            FileSecurity.secure_file_operations(self.private_key_file)
            FileSecurity.secure_file_operations(self.public_key_file)
            FileSecurity.secure_file_operations(self.key_metadata_file)
            
            logger.info(f"Keys saved securely to {self.key_store_path}")
            
        except Exception as e:
            raise CryptoEngineError(f"Failed to save keys: {e}")
    
    def load_keys(self, password: Optional[str] = None) -> Tuple[bytes, bytes]:
        """
        Load keys from storage.
        
        Args:
            password: Password for decryption (uses instance password if None)
            
        Returns:
            Tuple of (private_key, public_key)
        """
        if password is None:
            password = self.password
        
        if not password:
            raise CryptoEngineError("Password required for key decryption")
        
        try:
            # Check file permissions
            FileSecurity.check_file_permissions(self.private_key_file)
            FileSecurity.check_file_permissions(self.public_key_file)
            FileSecurity.check_file_permissions(self.key_metadata_file)
            
            # Load metadata
            with open(self.key_metadata_file, 'r') as f:
                metadata = json.load(f)
            
            # Load and decrypt private key
            with open(self.private_key_file, 'rb') as f:
                encrypted_private = f.read()
            
            salt = bytes.fromhex(metadata['salt'])
            private_key = self._decrypt_data(encrypted_private, password, salt)
            
            # Load public key
            with open(self.public_key_file, 'rb') as f:
                public_key = f.read()
            
            # Validate loaded keys
            if not KeyValidator.validate_key_structure(private_key, metadata['key_size']):
                raise KeyValidationError("Loaded private key validation failed")
            
            if not KeyValidator.validate_public_key(public_key):
                raise KeyValidationError("Loaded public key validation failed")
            
            logger.info("Keys loaded successfully")
            return private_key, public_key
            
        except Exception as e:
            raise CryptoEngineError(f"Failed to load keys: {e}")
    
    def _atomic_save(self, file_path: Path, data: bytes) -> None:
        """Save data atomically using temporary file."""
        with tempfile.NamedTemporaryFile(
            dir=file_path.parent, 
            delete=False, 
            mode='wb'
        ) as temp_file:
            temp_file.write(data)
            temp_file.flush()
            os.fsync(temp_file.fileno())
            temp_path = Path(temp_file.name)
        
        # Atomic move
        temp_path.replace(file_path)
    
    def _atomic_save_json(self, file_path: Path, data: Dict[str, Any]) -> None:
        """Save JSON data atomically."""
        with tempfile.NamedTemporaryFile(
            dir=file_path.parent, 
            delete=False, 
            mode='w'
        ) as temp_file:
            json.dump(data, temp_file, indent=2)
            temp_file.flush()
            os.fsync(temp_file.fileno())
            temp_path = Path(temp_file.name)
        
        # Atomic move
        temp_path.replace(file_path)
    
    def change_password(self, old_password: str, new_password: str) -> None:
        """
        Change key encryption password.
        
        Args:
            old_password: Current password
            new_password: New password
        """
        try:
            # Load keys with old password
            private_key, public_key = self.load_keys(old_password)
            
            # Save with new password
            self.save_keys(private_key, public_key, new_password)
            
            # Update instance password
            self.password = new_password
            
            logger.info("Password changed successfully")
            
        except Exception as e:
            raise CryptoEngineError(f"Failed to change password: {e}")
    
    def key_exists(self) -> bool:
        """Check if keys exist in storage."""
        return (
            self.private_key_file.exists() and
            self.public_key_file.exists() and
            self.key_metadata_file.exists()
        )
    
    def get_key_info(self) -> Dict[str, Any]:
        """Get information about stored keys."""
        if not self.key_exists():
            return {'exists': False}
        
        try:
            with open(self.key_metadata_file, 'r') as f:
                metadata = json.load(f)
            
            return {
                'exists': True,
                'algorithm': metadata.get('algorithm'),
                'key_size': metadata.get('key_size'),
                'public_key_size': metadata.get('public_key_size'),
                'encryption': metadata.get('encryption'),
                'kdf': metadata.get('kdf'),
            }
        except Exception as e:
            logger.error(f"Failed to get key info: {e}")
            return {'exists': True, 'error': str(e)} 