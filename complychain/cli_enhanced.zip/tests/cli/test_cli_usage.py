"""
CLI usage tests for ComplyChain.

This module tests the Typer-based CLI interface using subprocess
to verify commands work correctly in a real environment.
"""

import json
import subprocess
import tempfile
from pathlib import Path
import pytest
from unittest.mock import patch, MagicMock


@pytest.fixture
def sample_transaction():
    """Create a sample transaction for testing."""
    return {
        "amount": 5000,
        "currency": "USD",
        "timestamp": 1640995200,
        "sender": "test_sender",
        "recipient": "test_recipient",
        "transaction_type": "wire_transfer",
        "latitude": 40.7128,
        "longitude": -74.0060,
        "account_age_days": 365,
        "transaction_count": 50,
        "avg_transaction_amount": 1000,
        "is_high_value": False,
        "is_cross_border": False,
        "is_wire_transfer": True,
        "is_new_recipient": False,
        "is_after_hours": False,
    }


@pytest.fixture
def temp_files():
    """Create temporary files for testing."""
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        # Create sample transaction file
        tx_file = temp_path / "sample_tx.json"
        with open(tx_file, 'w') as f:
            json.dump({
                "amount": 5000,
                "currency": "USD",
                "timestamp": 1640995200,
            }, f)
        
        # Create sample data file for signing
        data_file = temp_path / "sample_data.json"
        with open(data_file, 'w') as f:
            json.dump({"test": "data"}, f)
        
        yield {
            'temp_dir': temp_path,
            'tx_file': tx_file,
            'data_file': data_file,
        }


class TestCLICommands:
    """Test CLI command functionality."""
    
    @pytest.mark.cli
    def test_help_command(self):
        """Test that help command works."""
        result = subprocess.run(
            ["python", "-m", "complychain.cli_enhanced", "--help"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        assert result.returncode == 0
        assert "ComplyChain" in result.stdout
        assert "GLBA compliance toolkit" in result.stdout
    
    @pytest.mark.cli
    def test_scan_help(self):
        """Test scan command help."""
        result = subprocess.run(
            ["python", "-m", "complychain.cli_enhanced", "scan", "--help"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        assert result.returncode == 0
        assert "Scan a transaction" in result.stdout
        assert "--quantum-safe" in result.stdout
    
    @pytest.mark.cli
    def test_sign_help(self):
        """Test sign command help."""
        result = subprocess.run(
            ["python", "-m", "complychain.cli_enhanced", "sign", "--help"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        assert result.returncode == 0
        assert "Sign a file" in result.stdout
        assert "--quantum-safe" in result.stdout
    
    @pytest.mark.cli
    def test_verify_help(self):
        """Test verify command help."""
        result = subprocess.run(
            ["python", "-m", "complychain.cli_enhanced", "verify", "--help"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        assert result.returncode == 0
        assert "Verify a file signature" in result.stdout
    
    @pytest.mark.cli
    def test_report_help(self):
        """Test report command help."""
        result = subprocess.run(
            ["python", "-m", "complychain.cli_enhanced", "report", "--help"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        assert result.returncode == 0
        assert "Generate compliance reports" in result.stdout
    
    @pytest.mark.cli
    def test_audit_help(self):
        """Test audit command help."""
        result = subprocess.run(
            ["python", "-m", "complychain.cli_enhanced", "audit", "--help"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        assert result.returncode == 0
        assert "Audit log operations" in result.stdout
    
    @pytest.mark.cli
    def test_key_help(self):
        """Test key command help."""
        result = subprocess.run(
            ["python", "-m", "complychain.cli_enhanced", "key", "--help"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        assert result.returncode == 0
        assert "Key management operations" in result.stdout
    
    @pytest.mark.cli
    def test_train_model_help(self):
        """Test train-model command help."""
        result = subprocess.run(
            ["python", "-m", "complychain.cli_enhanced", "train-model", "--help"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        assert result.returncode == 0
        assert "Train ML model" in result.stdout
    
    @pytest.mark.cli
    def test_compliance_help(self):
        """Test compliance command help."""
        result = subprocess.run(
            ["python", "-m", "complychain.cli_enhanced", "compliance", "--help"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        assert result.returncode == 0
        assert "Compliance operations" in result.stdout
    
    @pytest.mark.cli
    def test_benchmark_help(self):
        """Test benchmark command help."""
        result = subprocess.run(
            ["python", "-m", "complychain.cli_enhanced", "benchmark", "--help"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        assert result.returncode == 0
        assert "Run performance benchmarks" in result.stdout
    
    @pytest.mark.cli
    def test_verbose_flag(self):
        """Test verbose flag functionality."""
        result = subprocess.run(
            ["python", "-m", "complychain.cli_enhanced", "--verbose", "--help"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        assert result.returncode == 0
        assert "ComplyChain" in result.stdout
    
    @pytest.mark.cli
    def test_log_level_flag(self):
        """Test log level flag functionality."""
        result = subprocess.run(
            ["python", "-m", "complychain.cli_enhanced", "--log-level", "DEBUG", "--help"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        assert result.returncode == 0
        assert "ComplyChain" in result.stdout
    
    @pytest.mark.cli
    def test_dry_run_flag(self):
        """Test dry run flag functionality."""
        result = subprocess.run(
            ["python", "-m", "complychain.cli_enhanced", "--dry-run", "--help"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        assert result.returncode == 0
        assert "ComplyChain" in result.stdout


class TestCLIErrorHandling:
    """Test CLI error handling."""
    
    @pytest.mark.cli
    def test_invalid_command(self):
        """Test invalid command handling."""
        result = subprocess.run(
            ["python", "-m", "complychain.cli_enhanced", "invalid-command"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        assert result.returncode != 0
        assert "No such command" in result.stderr or "Error" in result.stderr
    
    @pytest.mark.cli
    def test_missing_required_argument(self):
        """Test missing required argument handling."""
        result = subprocess.run(
            ["python", "-m", "complychain.cli_enhanced", "scan"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        assert result.returncode != 0
        assert "Missing argument" in result.stderr or "Error" in result.stderr
    
    @pytest.mark.cli
    def test_invalid_file_path(self):
        """Test invalid file path handling."""
        result = subprocess.run(
            ["python", "-m", "complychain.cli_enhanced", "scan", "--file", "nonexistent.json"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        assert result.returncode != 0
        assert "Error" in result.stderr or "FileNotFoundError" in result.stderr
    
    @pytest.mark.cli
    def test_invalid_log_level(self):
        """Test invalid log level handling."""
        result = subprocess.run(
            ["python", "-m", "complychain.cli_enhanced", "--log-level", "INVALID", "--help"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        # Should still work but might show a warning
        assert result.returncode == 0


class TestCLIArgumentValidation:
    """Test CLI argument validation."""
    
    @pytest.mark.cli
    def test_scan_with_valid_file(self, temp_files):
        """Test scan command with valid transaction file."""
        # This test might fail if the actual scanning logic isn't fully implemented
        # but it should at least parse arguments correctly
        result = subprocess.run(
            ["python", "-m", "complychain.cli_enhanced", "scan", "--file", str(temp_files['tx_file'])],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        # Should either succeed or fail gracefully with a meaningful error
        assert result.returncode in [0, 1]
    
    @pytest.mark.cli
    def test_scan_with_quantum_safe_flag(self, temp_files):
        """Test scan command with quantum-safe flag."""
        result = subprocess.run(
            [
                "python", "-m", "complychain.cli_enhanced", 
                "scan", "--file", str(temp_files['tx_file']), "--quantum-safe"
            ],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        # Should either succeed or fail gracefully
        assert result.returncode in [0, 1]
    
    @pytest.mark.cli
    def test_sign_with_valid_file(self, temp_files):
        """Test sign command with valid data file."""
        # Mock password input
        with patch('builtins.input', return_value='test_password'):
            result = subprocess.run(
                [
                    "python", "-m", "complychain.cli_enhanced", 
                    "sign", "--file", str(temp_files['data_file']), "--quantum-safe"
                ],
                capture_output=True,
                text=True,
                timeout=30,
                input='test_password\n'
            )
        
        # Should either succeed or fail gracefully
        assert result.returncode in [0, 1]
    
    @pytest.mark.cli
    def test_benchmark_with_samples(self):
        """Test benchmark command with sample count."""
        result = subprocess.run(
            [
                "python", "-m", "complychain.cli_enhanced", 
                "benchmark", "--samples", "10"
            ],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        # Should either succeed or fail gracefully
        assert result.returncode in [0, 1]


class TestCLIOutputFormat:
    """Test CLI output formatting."""
    
    @pytest.mark.cli
    def test_help_output_format(self):
        """Test that help output is properly formatted."""
        result = subprocess.run(
            ["python", "-m", "complychain.cli_enhanced", "--help"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        assert result.returncode == 0
        output = result.stdout
        
        # Check for proper formatting
        assert "Usage:" in output
        assert "Commands:" in output
        assert "Options:" in output
    
    @pytest.mark.cli
    def test_command_help_format(self):
        """Test that command help is properly formatted."""
        result = subprocess.run(
            ["python", "-m", "complychain.cli_enhanced", "scan", "--help"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        assert result.returncode == 0
        output = result.stdout
        
        # Check for proper formatting
        assert "Usage:" in output
        assert "Arguments:" in output
        assert "Options:" in output 