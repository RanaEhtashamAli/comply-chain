#!/usr/bin/env python3
"""
Quick test suite for ComplyChainCrypto class
Run this to quickly verify basic functionality
"""

import os
import tempfile
import json
import hashlib
from unittest.mock import patch, MagicMock

def test_owasp_2024_parameters():
    """Test OWASP 2024 security parameters"""
    from complychain.crypto_engine import SCRYPT_N, SCRYPT_R, MIN_SALT_LEN
    
    print("🔍 Testing OWASP 2024 Parameters...")
    
    assert SCRYPT_N == 2**18, f"Expected SCRYPT_N=2^18, got {SCRYPT_N}"
    assert SCRYPT_R == 12, f"Expected SCRYPT_R=12, got {SCRYPT_R}"
    assert MIN_SALT_LEN == 32, f"Expected MIN_SALT_LEN=32, got {MIN_SALT_LEN}"
    
    print(f"✅ OWASP 2024 Parameters: N={SCRYPT_N}, R={SCRYPT_R}, Salt={MIN_SALT_LEN}")

def test_basic_functionality():
    """Test basic crypto functionality"""
    from complychain.crypto_engine import ComplyChainCrypto
    
    print("🔍 Testing Basic Functionality...")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        key_path = os.path.join(temp_dir, "test_keys.enc")
        password = "test_password_123"
        
        # Mock FIPS self-test
        with patch('complychain.crypto_engine._load_fips_vectors') as mock_load:
            mock_load.return_value = (b"test", b"pub", b"sig")
            with patch('complychain.crypto_engine.dilithium3.verify') as mock_verify:
                mock_verify.return_value = True
                
                # Initialize crypto engine
                crypto = ComplyChainCrypto(key_store_path=key_path, password=password)
                
                # Test basic operations
                with crypto.password_context(password):
                    test_data = b"Hello, ComplyChain!"
                    signature, pub_key = crypto.sign(test_data)
                    assert crypto.verify(test_data, signature, pub_key)
                
                print("✅ Basic signing and verification works")
                print("✅ Key generation and storage works")
                print("✅ Password context manager works")

def test_security_features():
    """Test security features"""
    from complychain.crypto_engine import ComplyChainCrypto, KeyValidationError
    
    print("🔍 Testing Security Features...")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        key_path = os.path.join(temp_dir, "test_keys.enc")
        password = "test_password_123"
        
        # Mock FIPS self-test
        with patch('complychain.crypto_engine._load_fips_vectors') as mock_load:
            mock_load.return_value = (b"test", b"pub", b"sig")
            with patch('complychain.crypto_engine.dilithium3.verify') as mock_verify:
                mock_verify.return_value = True
                
                crypto = ComplyChainCrypto(key_store_path=key_path, password=password)
                
                # Test memory protection
                assert isinstance(crypto._password, bytearray)
                assert hasattr(crypto, '_locked_buffers')
                print("✅ Memory protection features active")
                
                # Test salt validation
                valid_salt = os.urandom(32)
                crypto._validate_salt(valid_salt)
                
                # Test weak salt detection
                try:
                    crypto._validate_salt(b"short")
                    print("❌ Weak salt detection failed")
                    return False
                except KeyValidationError:
                    print("✅ Weak salt detection works")
                
                # Test weak key pattern detection
                try:
                    crypto._validate_key_structure(bytes(1952))  # All zeros
                    print("❌ Weak key pattern detection failed")
                    return False
                except KeyValidationError:
                    print("✅ Weak key pattern detection works")
                
                # Test file permissions
                stat = os.stat(key_path)
                if stat.st_mode & 0o777 == 0o600:
                    print("✅ Secure file permissions (600)")
                else:
                    print("❌ Insecure file permissions")
                    return False

def test_compliance():
    """Test compliance features"""
    from complychain.crypto_engine import ComplyChainCrypto
    
    print("🔍 Testing Compliance Features...")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        key_path = os.path.join(temp_dir, "test_keys.enc")
        password = "test_password_123"
        
        # Mock FIPS self-test
        with patch('complychain.crypto_engine._load_fips_vectors') as mock_load:
            mock_load.return_value = (b"test", b"pub", b"sig")
            with patch('complychain.crypto_engine.dilithium3.verify') as mock_verify:
                mock_verify.return_value = True
                
                crypto = ComplyChainCrypto(key_store_path=key_path, password=password)
                
                # Test Dilithium Level 3
                assert crypto.pub is not None
                assert len(crypto.pub) > 0
                print("✅ CRYSTALS-Dilithium Level 3 implemented")
                
                # Test quantum-resistant signing
                with crypto.password_context(password):
                    test_data = b"GLBA compliance test"
                    signature, pub_key = crypto.sign(test_data)
                    assert crypto.verify(test_data, signature, pub_key)
                print("✅ Quantum-resistant signing/verification works")
                
                # Test key file structure
                with open(key_path, 'r') as f:
                    key_data = json.load(f)
                    assert key_data.get('version') == '3.0'
                    assert 'scrypt_params' in key_data
                    assert key_data['scrypt_params']['n'] == 2**18
                    assert key_data['scrypt_params']['r'] == 12
                print("✅ Key file structure compliant")

def test_performance():
    """Test performance characteristics"""
    from complychain.crypto_engine import ComplyChainCrypto
    import time
    
    print("🔍 Testing Performance...")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        key_path = os.path.join(temp_dir, "test_keys.enc")
        password = "test_password_123"
        
        # Mock FIPS self-test
        with patch('complychain.crypto_engine._load_fips_vectors') as mock_load:
            mock_load.return_value = (b"test", b"pub", b"sig")
            with patch('complychain.crypto_engine.dilithium3.verify') as mock_verify:
                mock_verify.return_value = True
                
                crypto = ComplyChainCrypto(key_store_path=key_path, password=password)
                
                # Test signing performance
                test_data = b"Performance test data" * 1000  # ~20KB
                
                start_time = time.time()
                with crypto.password_context(password):
                    signature, pub_key = crypto.sign(test_data)
                    verify_result = crypto.verify(test_data, signature, pub_key)
                end_time = time.time()
                
                duration = end_time - start_time
                print(f"⏱️  Sign/Verify 20KB: {duration:.2f}s")
                
                if duration < 10.0:
                    print("✅ Performance within acceptable limits")
                else:
                    print("⚠️  Performance slower than expected")

def main():
    """Run all quick tests"""
    print("🚀 ComplyChain GLBA Quick Test Suite")
    print("=" * 50)
    
    try:
        test_owasp_2024_parameters()
        test_basic_functionality()
        test_security_features()
        test_compliance()
        test_performance()
        
        print("\n" + "=" * 50)
        print("🎉 All quick tests passed!")
        print("\nCompliance Status:")
        print("✅ GLBA §314.4(c)(2) Quantum Security")
        print("✅ NIST FIPS 203 (CRYSTALS-Dilithium)")
        print("✅ FIPS 140-3 Level 1")
        print("✅ OWASP 2024 Security Parameters")
        print("✅ NIST SP 800-131A Key Management")
        
    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    return True

if __name__ == "__main__":
    main() 