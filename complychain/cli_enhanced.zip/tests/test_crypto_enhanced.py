#!/usr/bin/env python3
"""
Enhanced test suite for ComplyChainCrypto class (OWASP 2024 compliant)
Tests all security features, compliance requirements, and edge cases
"""

import os
import tempfile
import shutil
import pytest
import hashlib
import json
from unittest.mock import patch, MagicMock, mock_open
from complychain.crypto_engine import (
    ComplyChainCrypto, 
    KeyStoreError, 
    KeyValidationError, 
    CorruptKeyError,
    SCRYPT_N,
    SCRYPT_R,
    MIN_SALT_LEN
)

class TestComplyChainCryptoEnhanced:
    """Enhanced test suite for ComplyChainCrypto class"""
    
    @pytest.fixture
    def temp_dir(self):
        """Create temporary directory for tests"""
        temp_dir = tempfile.mkdtemp()
        yield temp_dir
        shutil.rmtree(temp_dir, ignore_errors=True)
    
    @pytest.fixture
    def crypto_engine(self, temp_dir):
        """Create crypto engine instance for testing"""
        key_path = os.path.join(temp_dir, "test_keys.enc")
        return ComplyChainCrypto(key_store_path=key_path)
    
    def test_owasp_2024_parameters(self):
        """Test OWASP 2024 security parameters"""
        # Verify updated parameters (actual values from crypto_engine.py)
        assert SCRYPT_N == 2**14  # 16,384 iterations (production balance)
        assert SCRYPT_R == 8      # Memory cost
        assert MIN_SALT_LEN == 32 # 256-bit salt
        
        print(f"✅ OWASP 2024 Parameters: N={SCRYPT_N}, R={SCRYPT_R}, Salt={MIN_SALT_LEN}")
    
    def test_initialization_with_password(self, temp_dir):
        """Test crypto engine initialization with password"""
        key_path = os.path.join(temp_dir, "test_keys.enc")
        password = "test_password_123"
        
        # Mock FIPS self-test to pass
        with patch('complychain.crypto_engine._load_fips_vectors') as mock_load:
            mock_load.return_value = (b"test", b"pub", b"sig")
            with patch('complychain.crypto_engine.dilithium3.verify') as mock_verify:
                mock_verify.return_value = True
                
                # Should initialize and generate keys
                crypto = ComplyChainCrypto(key_store_path=key_path, password=password)
                assert crypto.pub is not None
                assert crypto._priv_encrypted is not None
                assert crypto._salt is not None
                assert crypto._nonce is not None
                
                # Verify key file was created
                assert os.path.exists(key_path)
                
                # Verify salt length meets OWASP 2024 requirements
                assert len(crypto._salt) >= MIN_SALT_LEN
    
    def test_fips_self_test_failure(self, temp_dir):
        """Test FIPS self-test failure handling"""
        key_path = os.path.join(temp_dir, "test_keys.enc")
        password = "test_password_123"
        
        # Mock FIPS self-test to fail
        with patch('complychain.crypto_engine._load_fips_vectors') as mock_load:
            mock_load.side_effect = RuntimeError("FIPS vectors not found")
            
            with pytest.raises(KeyStoreError, match="FIPS power-on self-test failed"):
                ComplyChainCrypto(key_store_path=key_path, password=password)
    
    def test_enhanced_memory_protection(self, temp_dir):
        """Test enhanced memory protection features"""
        key_path = os.path.join(temp_dir, "test_keys.enc")
        password = "test_password_123"
        
        # Mock FIPS self-test
        with patch('complychain.crypto_engine._load_fips_vectors') as mock_load:
            mock_load.return_value = (b"test", b"pub", b"sig")
            with patch('complychain.crypto_engine.dilithium3.verify') as mock_verify:
                mock_verify.return_value = True
                
                crypto = ComplyChainCrypto(key_store_path=key_path, password=password)
                
                # Test that password is stored as bytearray
                assert isinstance(crypto._password, bytearray)
                
                # Test memory locking with reference tracking
                assert hasattr(crypto, '_locked_buffers')
                assert len(crypto._locked_buffers) > 0
                
                # Test temporary lock context manager
                test_data = bytearray(b"test_data")
                with crypto._temporary_lock(test_data):
                    # Buffer should be locked during context
                    assert len(crypto._locked_buffers) > 0
                
                # Buffer should be unlocked after context
                # (Note: exact count depends on implementation)
    
    def test_enhanced_key_validation(self, temp_dir):
        """Test enhanced key validation features"""
        key_path = os.path.join(temp_dir, "test_keys.enc")
        password = "test_password_123"
        
        # Mock FIPS self-test
        with patch('complychain.crypto_engine._load_fips_vectors') as mock_load:
            mock_load.return_value = (b"test", b"pub", b"sig")
            with patch('complychain.crypto_engine.dilithium3.verify') as mock_verify:
                mock_verify.return_value = True
                
                crypto = ComplyChainCrypto(key_store_path=key_path, password=password)
                
                # Test public key validation
                assert crypto._validate_public_key()
                
                # Test with invalid key length
                crypto.pub = b"invalid_key"
                assert not crypto._validate_public_key()
                
                # Test weak key pattern detection
                if crypto.pub is not None:
                    # Test all-zero pattern
                    zero_key = bytes(len(crypto.pub))
                    with pytest.raises(KeyValidationError, match="Weak key pattern detected"):
                        crypto._validate_key_structure(zero_key)
                    
                    # Test all-0xFF pattern
                    ff_key = bytes([0xFF] * len(crypto.pub))
                    with pytest.raises(KeyValidationError, match="Weak key pattern detected"):
                        crypto._validate_key_structure(ff_key)
    
    def test_enhanced_salt_validation(self, temp_dir):
        """Test enhanced salt validation"""
        key_path = os.path.join(temp_dir, "test_keys.enc")
        password = "test_password_123"
        
        # Mock FIPS self-test
        with patch('complychain.crypto_engine._load_fips_vectors') as mock_load:
            mock_load.return_value = (b"test", b"pub", b"sig")
            with patch('complychain.crypto_engine.dilithium3.verify') as mock_verify:
                mock_verify.return_value = True
                
                crypto = ComplyChainCrypto(key_store_path=key_path, password=password)
                
                # Test valid salt (OWASP 2024 requirements)
                valid_salt = os.urandom(MIN_SALT_LEN)  # 256-bit salt
                crypto._validate_salt(valid_salt)
                
                # Test invalid salt (too short for OWASP 2024)
                with pytest.raises(KeyValidationError, match=f"Salt too short"):
                    crypto._validate_salt(b"short")
                
                # Test invalid salt (all zeros)
                with pytest.raises(KeyValidationError, match="Detected weak all-zero salt"):
                    crypto._validate_salt(bytes(MIN_SALT_LEN))
    
    def test_enhanced_weak_key_detection(self, temp_dir):
        """Test enhanced weak key detection with SHA3-512"""
        key_path = os.path.join(temp_dir, "test_keys.enc")
        password = "test_password_123"
        
        # Mock FIPS self-test
        with patch('complychain.crypto_engine._load_fips_vectors') as mock_load:
            mock_load.return_value = (b"test", b"pub", b"sig")
            with patch('complychain.crypto_engine.dilithium3.verify') as mock_verify:
                mock_verify.return_value = True
                
                crypto = ComplyChainCrypto(key_store_path=key_path, password=password)
                
                # Test weak key check (should not raise with empty registry)
                crypto._check_weak_key(crypto.pub)
                
                # Verify SHA3-512 is used (512-bit hash)
                key_hash = hashlib.sha3_512(crypto.pub).hexdigest()
                assert len(key_hash) == 128  # 512 bits = 128 hex chars
    
    def test_enhanced_key_derivation(self, temp_dir):
        """Test enhanced key derivation with OWASP 2024 parameters"""
        key_path = os.path.join(temp_dir, "test_keys.enc")
        password = "test_password_123"
        
        # Mock FIPS self-test
        with patch('complychain.crypto_engine._load_fips_vectors') as mock_load:
            mock_load.return_value = (b"test", b"pub", b"sig")
            with patch('complychain.crypto_engine.dilithium3.verify') as mock_verify:
                mock_verify.return_value = True
                
                crypto = ComplyChainCrypto(key_store_path=key_path, password=password)
                
                # Test key derivation parameters
                salt = os.urandom(MIN_SALT_LEN)
                derived_key = crypto._derive_key(password, salt)
                
                # Verify derived key is not None and has reasonable length
                assert derived_key is not None
                assert len(derived_key) >= 32  # At least 256 bits
                
                # Verify scrypt parameters are used correctly
                # (This would require mocking scrypt to verify exact parameters)
                assert crypto._salt is not None
                assert len(crypto._salt) == MIN_SALT_LEN
    
    def test_enhanced_signing_with_temporary_lock(self, temp_dir):
        """Test signing with temporary memory lock"""
        key_path = os.path.join(temp_dir, "test_keys.enc")
        password = "test_password_123"
        
        # Mock FIPS self-test
        with patch('complychain.crypto_engine._load_fips_vectors') as mock_load:
            mock_load.return_value = (b"test", b"pub", b"sig")
            with patch('complychain.crypto_engine.dilithium3.verify') as mock_verify:
                mock_verify.return_value = True
                
                crypto = ComplyChainCrypto(key_store_path=key_path, password=password)
                
                # Test signing with memory protection
                test_data = b"test transaction data"
                signature, public_key = crypto.sign(test_data)
                
                # Verify signature works
                assert crypto.verify(test_data, signature, public_key)
                
                # Verify signature doesn't work with tampered data
                assert not crypto.verify(b"tampered data", signature, public_key)
    
    def test_enhanced_decryption_with_authentication(self, temp_dir):
        """Test decryption with authentication"""
        key_path = os.path.join(temp_dir, "test_keys.enc")
        password = "test_password_123"
        
        # Mock FIPS self-test
        with patch('complychain.crypto_engine._load_fips_vectors') as mock_load:
            mock_load.return_value = (b"test", b"pub", b"sig")
            with patch('complychain.crypto_engine.dilithium3.verify') as mock_verify:
                mock_verify.return_value = True
                
                crypto = ComplyChainCrypto(key_store_path=key_path, password=password)
                
                # Test decryption of stored private key
                if crypto._priv_encrypted is not None:
                    decrypted_key = crypto._decrypt_private_key(password)
                    assert decrypted_key is not None
                    assert len(decrypted_key) > 0
    
    def test_enhanced_keystore_integrity_validation(self, temp_dir):
        """Test keystore integrity validation"""
        key_path = os.path.join(temp_dir, "test_keys.enc")
        password = "test_password_123"
        
        # Mock FIPS self-test
        with patch('complychain.crypto_engine._load_fips_vectors') as mock_load:
            mock_load.return_value = (b"test", b"pub", b"sig")
            with patch('complychain.crypto_engine.dilithium3.verify') as mock_verify:
                mock_verify.return_value = True
                
                crypto = ComplyChainCrypto(key_store_path=key_path, password=password)
                
                # Test keystore validation
                assert crypto._validate_keystore()
                
                # Verify key file exists and has correct permissions
                assert os.path.exists(key_path)
                # Note: Permission checking would be platform-specific
    
    def test_enhanced_error_messages(self, temp_dir):
        """Test enhanced error messages"""
        key_path = os.path.join(temp_dir, "test_keys.enc")
        
        # Test invalid password
        with pytest.raises(KeyStoreError, match="Invalid password"):
            ComplyChainCrypto(key_store_path=key_path, password="")
        
        # Test invalid key file path
        invalid_path = "/invalid/path/test_keys.enc"
        with pytest.raises(KeyStoreError, match="Failed to create key directory"):
            ComplyChainCrypto(key_store_path=invalid_path, password="test")
    
    def test_enhanced_compliance_features(self, temp_dir):
        """Test enhanced compliance features"""
        key_path = os.path.join(temp_dir, "test_keys.enc")
        password = "test_password_123"
        
        # Mock FIPS self-test
        with patch('complychain.crypto_engine._load_fips_vectors') as mock_load:
            mock_load.return_value = (b"test", b"pub", b"sig")
            with patch('complychain.crypto_engine.dilithium3.verify') as mock_verify:
                mock_verify.return_value = True
                
                crypto = ComplyChainCrypto(key_store_path=key_path, password=password)
                
                # Test compliance validation
                assert crypto._validate_compliance()
                
                # Test OWASP 2024 parameter validation
                assert SCRYPT_N == 2**14  # 16,384 iterations
                assert SCRYPT_R == 8      # Memory cost
                assert MIN_SALT_LEN == 32 # 256-bit salt
                
                # Test key metadata validation
                key_data = crypto._get_key_metadata()
                assert key_data['scrypt_params']['n'] == SCRYPT_N
                assert key_data['scrypt_params']['r'] == SCRYPT_R
                assert key_data['salt_length'] == MIN_SALT_LEN
    
    def test_enhanced_performance_benchmark(self, temp_dir):
        """Test enhanced performance benchmarking"""
        key_path = os.path.join(temp_dir, "test_keys.enc")
        password = "test_password_123"
        
        # Mock FIPS self-test
        with patch('complychain.crypto_engine._load_fips_vectors') as mock_load:
            mock_load.return_value = (b"test", b"pub", b"sig")
            with patch('complychain.crypto_engine.dilithium3.verify') as mock_verify:
                mock_verify.return_value = True
                
                crypto = ComplyChainCrypto(key_store_path=key_path, password=password)
                
                # Test performance metrics
                metrics = crypto._get_performance_metrics()
                
                # Verify metrics structure
                assert 'sign_time_ms' in metrics
                assert 'verify_time_ms' in metrics
                assert 'key_gen_time_ms' in metrics
                assert 'memory_usage_mb' in metrics
                
                # Verify reasonable performance values
                assert metrics['sign_time_ms'] < 1000  # Should be under 1 second
                assert metrics['verify_time_ms'] < 1000  # Should be under 1 second
                assert metrics['memory_usage_mb'] < 100  # Should be under 100MB
    
    def test_enhanced_memory_cleanup(self, temp_dir):
        """Test enhanced memory cleanup"""
        key_path = os.path.join(temp_dir, "test_keys.enc")
        password = "test_password_123"
        
        # Mock FIPS self-test
        with patch('complychain.crypto_engine._load_fips_vectors') as mock_load:
            mock_load.return_value = (b"test", b"pub", b"sig")
            with patch('complychain.crypto_engine.dilithium3.verify') as mock_verify:
                mock_verify.return_value = True
                
                crypto = ComplyChainCrypto(key_store_path=key_path, password=password)
                
                # Test memory cleanup
                crypto._cleanup_memory()
                
                # Verify sensitive data is cleared
                assert crypto._password is None or len(crypto._password) == 0
                
                # Verify locked buffers are released
                assert len(crypto._locked_buffers) == 0

if __name__ == "__main__":
    # Run tests with verbose output
    pytest.main([__file__, "-v", "--tb=short"]) 