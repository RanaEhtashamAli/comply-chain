from complychain.compliance.glba_engine import GLBA_REQUIREMENTS
from complychain.crypto_engine import ComplyChainCrypto
import pytest

def test_glba_section_coverage():
    """Verify all required GLBA sections are covered."""
    required_sections = [
        '§314.4(c)(1)',
        '§314.4(c)(2)',
        '§314.4(c)(3)',
        '§314.4(b)',
        '§314.4(d)',
        '§314.4(f)',
        '§314.4(e)'
    ]
    actual_sections = [v['section'] for v in GLBA_REQUIREMENTS.values()]
    for section in required_sections:
        assert section in actual_sections, f"Missing GLBA section: {section}"

def test_quantum_crypto():
    """Ensure quantum crypto (Dilithium) is available and works."""
    crypto = ComplyChainCrypto()
    data = b"GLBA compliance test"
    sig, pub = crypto.sign(data)
    assert crypto.verify(data, sig, pub)

def test_device_authentication():
    """Test GLBA §314.4(c)(3) device authentication logic."""
    from complychain.threat_scanner import GLBAScanner
    scanner = GLBAScanner()
    tx_without_device = {'amount': 50000, 'beneficiary': 'test'}
    result = scanner.scan(tx_without_device)
    assert 'MISSING_DEVICE_ID' in result['threat_flags']
    tx_with_device = {'amount': 50000, 'beneficiary': 'test', 'device_fingerprint': 'abc123'}
    result = scanner.scan(tx_with_device)
    assert 'MISSING_DEVICE_ID' not in result['threat_flags']

def test_cost_efficiency_calculation():
    """Verify cost efficiency calculation for regulatory compliance."""
    legacy_baseline = 290  # ms
    improved_time = 45  # ms
    efficiency_gain = (legacy_baseline - improved_time) / legacy_baseline * 100
    assert efficiency_gain > 0, "Efficiency gain must be positive"
    assert efficiency_gain > 80.0, "Efficiency gain should exceed 80%" 