import pytest
import time
import random
from complychain.threat_scanner import GLBAScanner
from complychain.crypto_engine import ComplyChainCrypto
from complychain.audit_system import GLBAAuditor

def test_scan_performance_100k_samples():
    """Test scan performance with 100k samples to ensure <50ms requirement."""
    scanner = GLBAScanner()
    
    # Generate 100k test transactions
    test_transactions = []
    for i in range(100000):
        tx = {
            'amount': random.randint(1000, 500000),
            'beneficiary': f'beneficiary_{i}',
            'sender': f'sender_{i}',
            'cross_border': random.choice([True, False]),
            'hour': random.randint(0, 23),
            'day_of_week': random.randint(1, 7),
            'device_fingerprint': f'device_{i}'
        }
        test_transactions.append(tx)
    
    # Train model with subset
    scanner.train_model(test_transactions[:1000])
    
    # Benchmark scan performance
    start_time = time.time()
    for tx in test_transactions:
        result = scanner.scan(tx)
        assert 'risk_score' in result
        assert 'threat_flags' in result
    end_time = time.time()
    
    avg_scan_time = (end_time - start_time) / 100000 * 1000  # Convert to ms
    assert avg_scan_time < 50, f"Scan time {avg_scan_time:.2f}ms exceeds 50ms requirement"

def test_merkle_tree_performance():
    """Test Merkle tree calculation performance with large audit logs."""
    auditor = GLBAAuditor()
    
    # Add many transactions to test Merkle tree optimization
    for i in range(2000):
        tx_data = {'amount': 10000 * (i + 1), 'beneficiary': f'ben_{i}'}
        signature = f'test_sig_{i}'.encode()
        auditor.log_transaction(tx_data, signature)
    
    # Test Merkle root calculation performance
    start_time = time.time()
    merkle_root = auditor.calculate_merkle_root()
    end_time = time.time()
    
    calculation_time = (end_time - start_time) * 1000  # Convert to ms
    assert calculation_time < 100, f"Merkle root calculation {calculation_time:.2f}ms too slow"
    assert len(merkle_root) == 64  # SHA-256 hash length

def test_persistent_key_management():
    """Test persistent key management in crypto engine."""
    crypto = ComplyChainCrypto()
    
    # Test that keys persist across multiple operations
    data1 = b"test transaction 1"
    data2 = b"test transaction 2"
    
    sig1, pub1 = crypto.sign(data1)
    sig2, pub2 = crypto.sign(data2)
    
    # Verify same public key is used (persistent keys)
    assert pub1 == pub2, "Public keys should be persistent"
    
    # Verify signatures work
    assert crypto.verify(data1, sig1, pub1) is True
    assert crypto.verify(data2, sig2, pub2) is True

def test_feature_normalization():
    """Test feature normalization improves ML accuracy."""
    scanner = GLBAScanner()
    
    # Test transactions with varying amounts
    test_cases = [
        {'amount': 1000, 'beneficiary': 'small', 'sender': 'user1'},
        {'amount': 50000, 'beneficiary': 'medium', 'sender': 'user2'},
        {'amount': 500000, 'beneficiary': 'large', 'sender': 'user3'},
        {'amount': 1000000, 'beneficiary': 'very_large', 'sender': 'user4'}  # Should be normalized to 1.0
    ]
    
    # Train model
    scanner.train_model(test_cases)
    
    # Test that all transactions can be processed without errors
    for tx in test_cases:
        result = scanner.scan(tx)
        assert 'risk_score' in result
        assert isinstance(result['risk_score'], int)
        assert 0 <= result['risk_score'] <= 100

def test_audit_chain_protection():
    """Test audit chain file protection."""
    import tempfile
    import os
    import json
    from datetime import datetime
    
    # Create temporary directory
    with tempfile.TemporaryDirectory() as temp_dir:
        chain_file = os.path.join(temp_dir, 'audit_chain.json')
        
        # Create initial chain
        initial_chain = {
            'genesis_block': {
                'timestamp': datetime.now().isoformat(),
                'hash': '0000000000000000000000000000000000000000000000000000000000000000',
                'glba_compliance_version': '314.4'
            }
        }
        
        with open(chain_file, 'w') as f:
            json.dump(initial_chain, f, indent=2)
        os.chmod(chain_file, 0o444)  # Read-only protection
        
        # Verify file is read-only
        stat = os.stat(chain_file)
        assert not (stat.st_mode & 0o200), "File should be read-only"
        
        # Verify file can be read
        with open(chain_file, 'r') as f:
            data = json.load(f)
            assert 'genesis_block' in data
            assert data['genesis_block']['glba_compliance_version'] == '314.4' 