import pytest
import tempfile
import os
import json
from complychain.crypto_engine import ComplyChainCrypto, KeyStoreError, QuantumSafeSigner

def test_context_manager_usage():
    """Test context manager for password handling and memory cleanup."""
    with ComplyChainCrypto(key_store_path="/tmp/test_keys.enc") as crypto:
        password = "test_password_123"
        with crypto.password_context(password):
            data = b"test data"
            sig, pub = crypto.sign(data)
            assert crypto.verify(data, sig, pub)
        assert crypto._password is None

def test_key_generation_and_signing():
    """Test key generation, signing, and verification."""
    with ComplyChainCrypto(key_store_path="/tmp/test_keys2.enc") as crypto:
        password = "test_password_456"
        with crypto.password_context(password):
            data = b"GLBA compliance test"
            sig, pub = crypto.sign(data)
            assert crypto.verify(data, sig, pub)

def test_key_persistence():
    """Test that keys persist across reloads."""
    key_path = "/tmp/test_keys3.enc"
    with ComplyChainCrypto(key_store_path=key_path) as crypto1:
        password = "test_password_789"
        with crypto1.password_context(password):
            data = b"persist test"
            sig, pub = crypto1.sign(data)
    with ComplyChainCrypto(key_store_path=key_path) as crypto2:
        with crypto2.password_context(password):
            assert crypto2.verify(b"persist test", sig, pub)

def test_memory_protection():
    """Test that sensitive data is zeroized after use."""
    key_path = "/tmp/test_keys4.enc"
    with ComplyChainCrypto(key_store_path=key_path) as crypto:
        password = "test_password_000"
        with crypto.password_context(password):
            data = b"memory test"
            sig, pub = crypto.sign(data)
        # After context, password should be cleared
        assert crypto._password is None

def test_error_handling():
    """Test error handling for invalid password."""
    key_path = "/tmp/test_keys5.enc"
    with ComplyChainCrypto(key_store_path=key_path) as crypto:
        password = "test_password_111"
        with crypto.password_context(password):
            data = b"error test"
            sig, pub = crypto.sign(data)
        # Try with wrong password
        try:
            with crypto.password_context("wrong_password"):
                crypto.sign(b"should fail")
            assert False, "Expected KeyStoreError"
        except KeyStoreError:
            pass

def test_compliance_features():
    """Test GLBA compliance features."""
    key_path = "/tmp/test_keys6.enc"
    with ComplyChainCrypto(key_store_path=key_path) as crypto:
        password = "test_password_222"
        with crypto.password_context(password):
            data = b"GLBA compliance test"
            sig, pub = crypto.sign(data)
            assert crypto.verify(data, sig, pub)


@pytest.mark.quantum
@pytest.mark.dilithium3
def test_dilithium3_key_generation():
    """Test Dilithium3 key generation."""
    signer = QuantumSafeSigner(algorithm="Dilithium3")
    private_key, public_key = signer.generate_keys()
    
    assert private_key is not None
    assert public_key is not None
    assert len(private_key) > 0
    assert len(public_key) > 0


@pytest.mark.quantum
@pytest.mark.dilithium3
def test_dilithium3_signing_and_verification():
    """Test Dilithium3 signing and verification."""
    signer = QuantumSafeSigner(algorithm="Dilithium3")
    private_key, public_key = signer.generate_keys()
    
    message = b"GLBA compliance test with quantum-safe cryptography"
    signature = signer.sign(message)
    
    assert signature is not None
    assert len(signature) > 0
    
    # Verify the signature
    is_valid = signer.verify(message, signature, public_key)
    assert is_valid is True


@pytest.mark.quantum
@pytest.mark.dilithium3
@pytest.mark.pem
def test_dilithium3_pem_export_import():
    """Test Dilithium3 PEM format export and import."""
    signer = QuantumSafeSigner(algorithm="Dilithium3")
    private_key, public_key = signer.generate_keys()
    
    # Export keys to PEM format
    private_pem = signer.export_private_key_pem()
    public_pem = signer.export_public_key_pem()
    
    assert "DILITHIUM3 PRIVATE KEY" in private_pem
    assert "DILITHIUM3 PUBLIC KEY" in public_pem
    
    # Create new signer and import keys
    new_signer = QuantumSafeSigner(algorithm="Dilithium3")
    new_signer.import_private_key_pem(private_pem)
    new_signer.import_public_key_pem(public_pem)
    
    # Test signing with imported keys
    message = b"Test message for PEM import/export"
    signature = new_signer.sign(message)
    is_valid = new_signer.verify(message, signature, public_key)
    assert is_valid is True


@pytest.mark.quantum
@pytest.mark.rsa
def test_rsa_fallback_when_oqs_unavailable():
    """Test RSA-4096 fallback when liboqs is not available."""
    # This test simulates the fallback behavior
    signer = QuantumSafeSigner(algorithm="Dilithium3")
    
    # Test that the signer works regardless of OQS availability
    private_key, public_key = signer.generate_keys()
    message = b"Test message with fallback"
    signature = signer.sign(message)
    is_valid = signer.verify(message, signature, public_key)
    assert is_valid is True


@pytest.mark.quantum
@pytest.mark.security
def test_quantum_safe_signer_error_handling():
    """Test error handling in QuantumSafeSigner."""
    signer = QuantumSafeSigner(algorithm="Dilithium3")
    
    # Test signing without generating keys first
    with pytest.raises(RuntimeError, match="No private key available"):
        signer.sign(b"test message")
    
    # Test verification with invalid signature
    private_key, public_key = signer.generate_keys()
    message = b"test message"
    invalid_signature = b"invalid signature"
    
    is_valid = signer.verify(message, invalid_signature, public_key)
    assert is_valid is False


@pytest.mark.quantum
@pytest.mark.parametrize("algorithm", ["Dilithium3", "RSA-4096"])
def test_algorithm_compatibility(algorithm):
    """Test compatibility with different algorithms."""
    signer = QuantumSafeSigner(algorithm=algorithm)
    private_key, public_key = signer.generate_keys()
    
    message = b"Algorithm compatibility test"
    signature = signer.sign(message)
    is_valid = signer.verify(message, signature, public_key)
    
    assert is_valid is True
    assert signer.algorithm in ["Dilithium3", "RSA-4096"] 