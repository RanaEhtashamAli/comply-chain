import pytest
import tempfile
import os
import json
from complychain.crypto_engine import ComplyChainCrypto, KeyStoreError

def test_key_generation_and_storage():
    """Test key generation and storage."""
    with tempfile.TemporaryDirectory() as temp_dir:
        key_path = os.path.join(temp_dir, "test_keys.enc")
        crypto = ComplyChainCrypto(key_store_path=key_path, password="test_password")
        data = b"GLBA test transaction"
        sig, pub = crypto.sign(data)
        assert crypto.verify(data, sig, pub)

def test_sign_and_verify():
    """Test sign and verify interface."""
    with tempfile.TemporaryDirectory() as temp_dir:
        key_path = os.path.join(temp_dir, "test_keys.enc")
        crypto = ComplyChainCrypto(key_store_path=key_path, password="test_password2")
        data = b"GLBA sign/verify test"
        sig, pub = crypto.sign(data)
        assert crypto.verify(data, sig, pub)
        assert not crypto.verify(b"tampered", sig, pub)

def test_password_change():
    """Test password change functionality."""
    with tempfile.TemporaryDirectory() as temp_dir:
        key_path = os.path.join(temp_dir, "test_keys.enc")
        crypto = ComplyChainCrypto(key_store_path=key_path, password="old_password")
        data = b"password change test"
        sig, pub = crypto.sign(data)
        crypto.change_password("old_password", "new_password")
        # Should still verify with new password
        assert crypto.verify(data, sig, pub)

def test_error_handling():
    """Test error handling for invalid password."""
    with tempfile.TemporaryDirectory() as temp_dir:
        key_path = os.path.join(temp_dir, "test_keys.enc")
        crypto = ComplyChainCrypto(key_store_path=key_path, password="test_password3")
        data = b"error handling test"
        sig, pub = crypto.sign(data)
        try:
            crypto.change_password("wrong_password", "another_password")
            assert False, "Expected KeyStoreError"
        except KeyStoreError:
            pass

def test_memory_protection():
    """Test that private keys are zeroized after use."""
    with tempfile.TemporaryDirectory() as temp_dir:
        key_path = os.path.join(temp_dir, 'test_keys.enc')
        password = "secure_test_password_123"
        
        crypto = ComplyChainCrypto(key_store_path=key_path, password=password)
        
        # Sign multiple times to test memory protection
        test_data1 = b"test transaction 1"
        test_data2 = b"test transaction 2"
        
        sig1, pub1 = crypto.sign(test_data1)
        sig2, pub2 = crypto.sign(test_data2)
        
        # Verify both signatures work (keys are properly managed)
        assert crypto.verify(test_data1, sig1, pub1) is True
        assert crypto.verify(test_data2, sig2, pub2) is True

def test_key_file_corruption():
    """Test handling of corrupted key files."""
    with tempfile.TemporaryDirectory() as temp_dir:
        key_path = os.path.join(temp_dir, 'test_keys.enc')
        
        # Create corrupted key file
        with open(key_path, 'w') as f:
            f.write("invalid json content")
        
        # Should handle corruption gracefully
        with pytest.raises(KeyStoreError, match="Invalid key file format"):
            crypto = ComplyChainCrypto(key_store_path=key_path, password="test_password") 