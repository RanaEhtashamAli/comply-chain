import pytest
from complychain.crypto_engine import ComplyChainCrypto

def test_sign_and_verify():
    crypto = ComplyChainCrypto()
    tx_data = b"test transaction"
    signature, pub_key = crypto.sign(tx_data)
    assert crypto.verify(tx_data, signature, pub_key)
    assert not crypto.verify(b"tampered", signature, pub_key) 