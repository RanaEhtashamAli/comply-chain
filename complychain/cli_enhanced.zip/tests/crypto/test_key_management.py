"""
Tests for key management functionality.

This module tests secure key storage, loading, and validation
with proper temporary file handling and security checks.
"""

import pytest
import tempfile
import os
from pathlib import Path
from unittest.mock import patch, MagicMock

from complychain.crypto.key_management import KeyManager
from complychain.exceptions import (
    KeyValidationError, 
    FilePermissionError, 
    CryptoEngineError
)


@pytest.fixture
def temp_key_store():
    """Create temporary key store directory."""
    with tempfile.TemporaryDirectory() as temp_dir:
        yield Path(temp_dir)


@pytest.fixture
def sample_keys():
    """Generate sample keys for testing."""
    # Dilithium3 key sizes
    private_key = b'0' * 4000  # Private key
    public_key = b'1' * 1952   # Public key
    return private_key, public_key


@pytest.fixture
def key_manager(temp_key_store):
    """Create key manager instance."""
    return KeyManager(temp_key_store, password="test_password")


class TestKeyManager:
    """Test key management functionality."""
    
    @pytest.mark.crypto
    @pytest.mark.security
    def test_initialization(self, temp_key_store):
        """Test key manager initialization."""
        km = KeyManager(temp_key_store, password="test_password")
        
        assert km.key_store_path == temp_key_store
        assert km.password == "test_password"
        assert km.SCRYPT_N == 16384
        assert km.SCRYPT_R == 8
        assert km.SCRYPT_P == 1
        assert km.MIN_SALT_LEN == 32
    
    @pytest.mark.crypto
    @pytest.mark.security
    def test_save_keys_success(self, key_manager, sample_keys):
        """Test successful key saving."""
        private_key, public_key = sample_keys
        
        key_manager.save_keys(private_key, public_key)
        
        # Check files exist
        assert key_manager.private_key_file.exists()
        assert key_manager.public_key_file.exists()
        assert key_manager.key_metadata_file.exists()
        
        # Check file permissions
        assert oct(key_manager.private_key_file.stat().st_mode)[-3:] == '600'
        assert oct(key_manager.public_key_file.stat().st_mode)[-3:] == '600'
        assert oct(key_manager.key_metadata_file.stat().st_mode)[-3:] == '600'
    
    @pytest.mark.crypto
    @pytest.mark.security
    def test_save_keys_invalid_private_key(self, key_manager, sample_keys):
        """Test saving with invalid private key."""
        _, public_key = sample_keys
        invalid_private_key = b'0' * 100  # Wrong size
        
        with pytest.raises(KeyValidationError, match="Invalid private key structure"):
            key_manager.save_keys(invalid_private_key, public_key)
    
    @pytest.mark.crypto
    @pytest.mark.security
    def test_save_keys_invalid_public_key(self, key_manager, sample_keys):
        """Test saving with invalid public key."""
        private_key, _ = sample_keys
        invalid_public_key = b'1' * 100  # Wrong size
        
        with pytest.raises(KeyValidationError, match="Invalid public key structure"):
            key_manager.save_keys(private_key, invalid_public_key)
    
    @pytest.mark.crypto
    @pytest.mark.security
    def test_save_keys_weak_key_patterns(self, key_manager, sample_keys):
        """Test saving with weak key patterns."""
        _, public_key = sample_keys
        weak_private_key = b'\x00' * 4000  # All zeros
        
        with pytest.raises(KeyValidationError, match="Weak key patterns detected"):
            key_manager.save_keys(weak_private_key, public_key)
    
    @pytest.mark.crypto
    @pytest.mark.security
    def test_load_keys_success(self, key_manager, sample_keys):
        """Test successful key loading."""
        private_key, public_key = sample_keys
        
        # Save keys first
        key_manager.save_keys(private_key, public_key)
        
        # Load keys
        loaded_private, loaded_public = key_manager.load_keys()
        
        assert loaded_private == private_key
        assert loaded_public == public_key
    
    @pytest.mark.crypto
    @pytest.mark.security
    def test_load_keys_wrong_password(self, key_manager, sample_keys):
        """Test loading with wrong password."""
        private_key, public_key = sample_keys
        
        # Save keys
        key_manager.save_keys(private_key, public_key)
        
        # Try to load with wrong password
        with pytest.raises(CryptoEngineError):
            key_manager.load_keys(password="wrong_password")
    
    @pytest.mark.crypto
    @pytest.mark.security
    def test_load_keys_missing_files(self, key_manager):
        """Test loading when files don't exist."""
        with pytest.raises(CryptoEngineError):
            key_manager.load_keys()
    
    @pytest.mark.crypto
    @pytest.mark.security
    def test_change_password_success(self, key_manager, sample_keys):
        """Test successful password change."""
        private_key, public_key = sample_keys
        
        # Save keys
        key_manager.save_keys(private_key, public_key)
        
        # Change password
        new_password = "new_test_password"
        key_manager.change_password("test_password", new_password)
        
        # Verify keys can be loaded with new password
        loaded_private, loaded_public = key_manager.load_keys(new_password)
        assert loaded_private == private_key
        assert loaded_public == public_key
    
    @pytest.mark.crypto
    @pytest.mark.security
    def test_change_password_wrong_old_password(self, key_manager, sample_keys):
        """Test password change with wrong old password."""
        private_key, public_key = sample_keys
        
        # Save keys
        key_manager.save_keys(private_key, public_key)
        
        # Try to change with wrong old password
        with pytest.raises(CryptoEngineError):
            key_manager.change_password("wrong_password", "new_password")
    
    @pytest.mark.crypto
    def test_key_exists_false(self, key_manager):
        """Test key_exists when no keys are present."""
        assert not key_manager.key_exists()
    
    @pytest.mark.crypto
    def test_key_exists_true(self, key_manager, sample_keys):
        """Test key_exists when keys are present."""
        private_key, public_key = sample_keys
        key_manager.save_keys(private_key, public_key)
        assert key_manager.key_exists()
    
    @pytest.mark.crypto
    def test_get_key_info_no_keys(self, key_manager):
        """Test get_key_info when no keys exist."""
        info = key_manager.get_key_info()
        assert info['exists'] is False
    
    @pytest.mark.crypto
    def test_get_key_info_with_keys(self, key_manager, sample_keys):
        """Test get_key_info when keys exist."""
        private_key, public_key = sample_keys
        key_manager.save_keys(private_key, public_key)
        
        info = key_manager.get_key_info()
        assert info['exists'] is True
        assert info['algorithm'] == 'Dilithium3'
        assert info['key_size'] == 4000
        assert info['public_key_size'] == 1952
        assert info['encryption'] == 'AES-GCM-256'
        assert info['kdf'] == 'Scrypt'
    
    @pytest.mark.crypto
    @pytest.mark.security
    def test_atomic_save_operations(self, key_manager):
        """Test atomic save operations."""
        test_data = b'test_data'
        
        # Test atomic save
        key_manager._atomic_save(key_manager.private_key_file, test_data)
        assert key_manager.private_key_file.exists()
        
        with open(key_manager.private_key_file, 'rb') as f:
            assert f.read() == test_data
    
    @pytest.mark.crypto
    @pytest.mark.security
    def test_atomic_save_json_operations(self, key_manager):
        """Test atomic JSON save operations."""
        test_data = {'test': 'data', 'number': 42}
        
        # Test atomic JSON save
        key_manager._atomic_save_json(key_manager.key_metadata_file, test_data)
        assert key_manager.key_metadata_file.exists()
        
        with open(key_manager.key_metadata_file, 'r') as f:
            import json
            loaded_data = json.load(f)
            assert loaded_data == test_data
    
    @pytest.mark.crypto
    @pytest.mark.security
    def test_encryption_decryption_roundtrip(self, key_manager):
        """Test encryption/decryption roundtrip."""
        test_data = b'secret_data_for_encryption_test'
        password = "test_password"
        
        # Encrypt
        encrypted_data, salt = key_manager._encrypt_data(test_data, password)
        
        # Decrypt
        decrypted_data = key_manager._decrypt_data(encrypted_data, password, salt)
        
        assert decrypted_data == test_data
    
    @pytest.mark.crypto
    @pytest.mark.security
    def test_encryption_wrong_password(self, key_manager):
        """Test encryption with wrong password."""
        test_data = b'secret_data'
        password = "correct_password"
        wrong_password = "wrong_password"
        
        # Encrypt
        encrypted_data, salt = key_manager._encrypt_data(test_data, password)
        
        # Try to decrypt with wrong password
        with pytest.raises(Exception):  # Should raise cryptography exception
            key_manager._decrypt_data(encrypted_data, wrong_password, salt)
    
    @pytest.mark.crypto
    @pytest.mark.security
    def test_key_derivation_consistency(self, key_manager):
        """Test key derivation consistency."""
        password = "test_password"
        salt = b'test_salt_32_bytes_long_for_testing'
        
        # Derive key twice
        key1 = key_manager._derive_key(password, salt)
        key2 = key_manager._derive_key(password, salt)
        
        assert key1 == key2
        assert len(key1) == 32  # 256-bit key
    
    @pytest.mark.crypto
    @pytest.mark.security
    def test_key_derivation_different_salts(self, key_manager):
        """Test key derivation with different salts."""
        password = "test_password"
        salt1 = b'salt1_32_bytes_long_for_testing_'
        salt2 = b'salt2_32_bytes_long_for_testing_'
        
        # Derive keys with different salts
        key1 = key_manager._derive_key(password, salt1)
        key2 = key_manager._derive_key(password, salt2)
        
        assert key1 != key2  # Different salts should produce different keys 